#include <Arduino.h>
#include <Wire.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <EEPROM.h>
#include <Adafruit_GFX.h>
#if defined(DEVLIN_OLED_SH1106)
  #include <Adafruit_SH110X.h>
  #define SSD1306_WHITE SH110X_WHITE
  #define SSD1306_BLACK SH110X_BLACK
  #define SSD1306_INVERSE SH110X_INVERSE
#else
  #include <Adafruit_SSD1306.h>
#endif
#include <time.h>
#include <sys/time.h>
#include <math.h>
#include <cstring>

// DEVLIN OS LAUNCHER V1.2 - Wemos D1 mini ESP8266 ESP-12F, 4 MB flash
// Pin map carefully re-read from the supplied Nethercap schematic:
// OLED SDA=D2/GPIO4, SCL=D1/GPIO5 (standard Wemos D1 mini ESP8266 I2C pins).
// Confirm=D7/GPIO13, Down=D6/GPIO12, Up=D5/GPIO14,
// Back=D3/GPIO0, Start=D4/GPIO2, battery sense=A0.
// Buttons are active-low to GND and use INPUT_PULLUP.
// D3/GPIO0 and D4/GPIO2 are boot-strap pins: release Back and Start at power-up/reset/flash.
static constexpr int PIN_SDA = 4;        // D2 / GPIO4 -> OLED SDA
static constexpr int PIN_SCL = 5;        // D1 / GPIO5 -> OLED SCL
static constexpr int PIN_CONFIRM = 13;   // D7 / GPIO13
static constexpr int PIN_DOWN = 12;      // D6 / GPIO12
static constexpr int PIN_UP = 14;        // D5 / GPIO14
static constexpr int PIN_BACK = 0;       // D3 / GPIO0
static constexpr int PIN_START = 2;      // D4 / GPIO2
static constexpr int PIN_BATTERY = A0;   // midpoint of external 100k:100k battery divider

static constexpr int OLED_W = 128;
static constexpr int OLED_H = 64;
#if defined(DEVLIN_OLED_SH1106)
Adafruit_SH1106G display(OLED_W, OLED_H, &Wire, -1);
#else
Adafruit_SSD1306 display(OLED_W, OLED_H, &Wire, -1);
#endif
ESP8266WebServer server(80);

// Small Preferences-compatible EEPROM store for ESP8266. Config changes are
// committed immediately; high-score writes are batched to reduce flash wear.
class Preferences {
 public:
  bool begin(const char *, bool) {
    if (!ready) {
      EEPROM.begin(4096);
      for (int i = 0; i < MAX_RECORDS; ++i) {
        readRecord(i, records[i]);
        if ((uint8_t)records[i].key[0] == 0xFF) memset(&records[i], 0, sizeof(Record));
        records[i].key[sizeof(records[i].key)-1] = '\0';
        records[i].value[sizeof(records[i].value)-1] = '\0';
      }
      ready = true;
      lastFlush = millis();
    }
    return true;
  }
  String getString(const char *key, const char *fallback) { return getValue(key, String(fallback)); }
  String getString(const char *key, const String &fallback) { return getValue(key, fallback); }
  int getInt(const char *key, int fallback) { String v = getValue(key, String(fallback)); return v.toInt(); }
  uint32_t getUInt(const char *key, uint32_t fallback) { String v = getValue(key, String((unsigned long)fallback)); return (uint32_t)strtoul(v.c_str(), nullptr, 10); }
  bool getBool(const char *key, bool fallback) { String v = getValue(key, String(fallback ? 1 : 0)); return v.toInt() != 0; }
  size_t putString(const char *key, const String &value) { return setValue(key, value, true); }
  size_t putInt(const char *key, int value) { return setValue(key, String(value), true); }
  size_t putBool(const char *key, bool value) { return setValue(key, String(value ? 1 : 0), true); }
  size_t putUInt(const char *key, uint32_t value) { return setValue(key, String((unsigned long)value), strncmp(key, "hs", 2) != 0); }
  void tick() { if (ready && dirtyAny() && (uint32_t)(millis() - lastFlush) >= 10000UL) flush(); }
 private:
  struct Record { char key[16]; char value[64]; };
  static constexpr int MAX_RECORDS = 50;
  Record records[MAX_RECORDS] = {};
  bool dirty[MAX_RECORDS] = {};
  bool ready = false;
  uint32_t lastFlush = 0;
  void readRecord(int i, Record &r) { uint8_t *p = reinterpret_cast<uint8_t *>(&r); for (size_t j=0; j<sizeof(Record); ++j) p[j] = EEPROM.read(i * sizeof(Record) + j); }
  String getValue(const char *key, const String &fallback) { for (int i=0; i<MAX_RECORDS; ++i) if (records[i].key[0] && strcmp(records[i].key, key)==0) return String(records[i].value); return fallback; }
  int findSlot(const char *key) { int empty = -1; for (int i=0; i<MAX_RECORDS; ++i) { if (records[i].key[0] && strcmp(records[i].key,key)==0) return i; if (!records[i].key[0] && empty<0) empty=i; } return empty; }
  size_t setValue(const char *key, const String &value, bool immediate) { if (!ready) return 0; int i=findSlot(key); if (i<0 || strlen(key)>=sizeof(records[i].key)) return 0; memset(&records[i],0,sizeof(Record)); strncpy(records[i].key,key,sizeof(records[i].key)-1); String v=value; if (v.length() >= sizeof(records[i].value)) v=v.substring(0,sizeof(records[i].value)-1); strncpy(records[i].value,v.c_str(),sizeof(records[i].value)-1); dirty[i]=true; if (immediate) flush(); return v.length(); }
  bool dirtyAny() { for (int i=0;i<MAX_RECORDS;++i) if (dirty[i]) return true; return false; }
  void flush() { if (!ready || !dirtyAny()) return; for (int i=0;i<MAX_RECORDS;++i) if (dirty[i]) { const uint8_t *p=reinterpret_cast<const uint8_t *>(&records[i]); for (size_t j=0;j<sizeof(Record);++j) EEPROM.write(i*sizeof(Record)+j,p[j]); dirty[i]=false; } EEPROM.commit(); lastFlush=millis(); }
};
Preferences prefs;

const char *DEFAULT_AP_PASS = "devlin1234";
const char *DEFAULT_WEB_PASS = "devlin1234";
String apPass, webPass, staSsid, staPass;
String profiles[30];
int activeProfile = 0;
bool timeSyncRequested = false;
uint32_t lastTimeSyncAttempt = 0;
bool oledOk = false;
bool animationsEnabled = true;
bool autoClockEnabled = true;
int settingsIndex = 0;
bool stopwatchRunning = false;
uint32_t stopwatchStartedAt = 0;
uint32_t stopwatchAccumulated = 0;
uint32_t stopwatchLaps = 0;

struct KeyState {
  uint8_t pin;
  bool lastRaw = HIGH;
  bool stable = HIGH;
  uint32_t lastChange = 0;
  uint32_t downAt = 0;
  bool pressedEvent = false;
  bool longEvent = false;
  bool longSent = false;
};
KeyState keys[] = {
  {PIN_CONFIRM}, {PIN_DOWN}, {PIN_UP}, {PIN_BACK}, {PIN_START}
};
enum KeyId { K_CONFIRM, K_DOWN, K_UP, K_BACK, K_START };
uint32_t lastInteraction = 0;
uint32_t lastRender = 0;
uint32_t lastBatteryRead = 0;
int batteryPercent = -1;
float batteryVoltage = 0.0f;

String htmlEscape(String s) {
  s.replace("&", "&amp;"); s.replace("<", "&lt;"); s.replace(">", "&gt;");
  s.replace("\"", "&quot;"); s.replace("'", "&#39;");
  return s;
}

String activeApSsid() {
  if (activeProfile < 0 || activeProfile > 29) activeProfile = 0;
  String s = profiles[activeProfile];
  s.trim();
  if (s.length() == 0) s = "LAUNCHER OS DEV1.1";
  if (s.length() > 32) s = s.substring(0, 32);
  return s;
}

void loadSettings() {
  prefs.begin("devlin", false);
  apPass = prefs.getString("appass", DEFAULT_AP_PASS);
  webPass = prefs.getString("webpass", DEFAULT_WEB_PASS);
  staSsid = prefs.getString("stassid", "");
  staPass = prefs.getString("stapass", "");
  activeProfile = prefs.getInt("active", 0);
  animationsEnabled = prefs.getBool("anim", true);
  autoClockEnabled = prefs.getBool("autoclk", true);
  if (apPass.length() < 8) apPass = DEFAULT_AP_PASS;
  if (webPass.length() < 8) webPass = DEFAULT_WEB_PASS;
  for (int i = 0; i < 30; ++i) {
    char key[8]; snprintf(key, sizeof(key), "p%02d", i);
    String fallback;
    if (i == 0) fallback = "LAUNCHER OS DEV1.1";
    else fallback = String("DEVLIN-NET-") + String(i + 1);
    profiles[i] = prefs.getString(key, fallback);
    if (profiles[i].length() > 32) profiles[i] = profiles[i].substring(0, 32);
  }
  if (activeProfile < 0 || activeProfile > 29) activeProfile = 0;
}

void saveProfile(int i, const String &name) {
  char key[8]; snprintf(key, sizeof(key), "p%02d", i);
  prefs.putString(key, name);
  profiles[i] = name;
}

void startWifi() {
  WiFi.mode(WIFI_AP_STA);
  WiFi.setSleepMode(WIFI_NONE_SLEEP);
  WiFi.setAutoReconnect(true);
  IPAddress ip(192, 168, 4, 1), gw(192, 168, 4, 1), mask(255, 255, 255, 0);
  WiFi.softAPConfig(ip, gw, mask);
  String ssid = activeApSsid();
  WiFi.softAP(ssid.c_str(), apPass.c_str(), 1, false, 4);
  if (staSsid.length() > 0) {
    WiFi.begin(staSsid.c_str(), staPass.c_str());
  }
}

void requestTimeSync() {
  if (WiFi.status() != WL_CONNECTED) return;
  const uint32_t nowMs = millis();
  const bool clockValid = time(nullptr) > 1700000000;
  const bool firstAttempt = !timeSyncRequested;
  const bool retryIfNoTime = !clockValid &&
      (lastTimeSyncAttempt == 0 || (uint32_t)(nowMs - lastTimeSyncAttempt) >= 60000UL);
  const bool periodicRefresh = clockValid &&
      (lastTimeSyncAttempt == 0 || (uint32_t)(nowMs - lastTimeSyncAttempt) >= 21600000UL);
  if (firstAttempt || retryIfNoTime || periodicRefresh) {
    configTzTime("WIB-7", "pool.ntp.org", "time.google.com", "time.cloudflare.com");
    timeSyncRequested = true;
    lastTimeSyncAttempt = nowMs;
  }
}

bool timeIsValid() {
  return time(nullptr) > 1700000000;
}

void setTimeFromEpoch(long epoch) {
  if (epoch < 1700000000L || epoch > 2200000000L) return;
  struct timeval tv;
  tv.tv_sec = epoch;
  tv.tv_usec = 0;
  settimeofday(&tv, nullptr);
}

void handleSetTime() {
  if (!server.authenticate("admin", webPass.c_str())) return server.requestAuthentication();
  if (server.hasArg("epoch")) setTimeFromEpoch(server.arg("epoch").toInt());
  server.send(200, "text/plain", timeIsValid() ? "Clock synced" : "Invalid time");
}

bool requireAuth() {
  if (server.authenticate("admin", webPass.c_str())) return true;
  server.requestAuthentication();
  return false;
}

String makeWebPage() {
  String h;
  h.reserve(9000);
  h += F("<!doctype html><html lang='id'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>");
  h += F("<title>DEVLIN OS Control</title><style>body{margin:0;background:#080d16;color:#eaf3ff;font:15px system-ui}main{max-width:760px;margin:auto;padding:18px}h1{color:#7cf7d4;margin-bottom:4px}small,.muted{color:#9aabc0}.card{background:#111b2b;border:1px solid #26384c;border-radius:14px;padding:16px;margin:14px 0}label{display:block;margin:10px 0 5px;color:#b8c8dc}input,select{box-sizing:border-box;width:100%;padding:11px;border-radius:8px;border:1px solid #34485f;background:#07101b;color:#fff}button{padding:12px 16px;border:0;border-radius:9px;background:#7cf7d4;color:#07101b;font-weight:700;margin-top:14px}details{border-top:1px solid #26384c;padding:8px 0}summary{cursor:pointer;color:#7cf7d4} .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:520px){.grid{grid-template-columns:1fr}}</style></head><body><main>");
  h += F("<h1>DEVLIN OS</h1><div class='muted'>LAUNCHER V1.1 · Web Control Center</div>");
  h += F("<div class='card'><b>Device status</b><p id='status'>Memuat status...</p><p class='muted'>Portal lokal: http://192.168.4.1/</p></div>");
  h += F("<form method='POST' action='/save'><div class='card'><h2>Wi-Fi & Access Point</h2><p class='muted'>Tersedia 30 preset nama SSID, tetapi hanya satu preset aktif yang dipancarkan pada satu waktu.</p><label>Preset SSID aktif</label><select name='active'>");
  for (int i = 0; i < 30; ++i) {
    h += "<option value='" + String(i) + "'" + (i == activeProfile ? " selected" : "") + ">" + String(i + 1) + " — " + htmlEscape(profiles[i]) + "</option>";
  }
  h += F("</select><label>Password Wi-Fi perangkat (min. 8 karakter; kosongkan untuk tetap memakai password saat ini)</label><input type='password' name='apPass' minlength='8' placeholder='Tidak diubah jika kosong'><label>Password admin web (min. 8 karakter; kosongkan untuk tetap)</label><input type='password' name='webPass' minlength='8' placeholder='Tidak diubah jika kosong'><div class='grid'><div><label>Wi-Fi router untuk sinkronisasi jam</label><input name='staSsid' maxlength='32' value='");
  h += htmlEscape(staSsid);
  h += F("' placeholder='Nama Wi-Fi rumah'></div><div><label>Password router (kosongkan untuk tetap)</label><input type='password' name='staPass' placeholder='Tidak diubah jika kosong'></div></div><label><input style='width:auto' type='checkbox' name='clearSta' value='1'> Hapus Wi-Fi router tersimpan</label></div>");
  h += F("<div class='card'><h2>30 preset nama SSID</h2><p class='muted'>Edit nama sesuai kebutuhan. Firmware ini tidak menyiarkan 30 SSID palsu sekaligus; hanya preset yang dipilih di atas yang aktif.</p>");
  for (int i = 0; i < 30; ++i) {
    char key[8]; snprintf(key, sizeof(key), "p%02d", i);
    h += "<details" + String(i == activeProfile ? " open" : "") + "><summary>Preset " + String(i + 1) + (i == activeProfile ? " · AKTIF" : "") + "</summary><label>Nama SSID</label><input maxlength='32' name='" + String(key) + "' value='" + htmlEscape(profiles[i]) + "'></details>";
  }
  h += F("<button type='submit'>Simpan Pengaturan</button></form></div><div class='card'><h2>Info</h2><p>Agar jam otomatis benar setelah perangkat dinyalakan ulang, simpan SSID dan password Wi-Fi yang memiliki internet. Jika hanya punya HP, aktifkan hotspot HP dan masukkan nama/password hotspot di kolom Wi-Fi router satu kali. Setelah tersimpan, ESP32 akan mencoba tersambung dan menyinkronkan jam WIB otomatis setiap boot; hotspot harus aktif dan internet tersedia saat ESP32 menyala. Jika tidak ada internet/hotspot, jam akurat tidak bisa dipulihkan setelah daya benar-benar putus tanpa modul RTC DS3231. Halaman ini juga mencoba menyinkronkan jam dari browser HP saat dibuka.</p><p class='muted'>Wi-Fi scan hanya menampilkan jaringan yang terdeteksi. Repeater internet penuh memerlukan build ESP-IDF dengan NAT; mode NAT tidak diaktifkan dalam build Arduino ini.</p><button onclick='location.href=\"/restart\"'>Restart perangkat</button></div>");
  h += F("<script>fetch('/status').then(r=>r.json()).then(s=>{document.getElementById('status').textContent='AP: '+s.ap+' · IP: '+s.ip+' · Router: '+s.sta+' · Baterai: '+s.battery+'%';}).catch(()=>{});fetch('/settime?epoch='+Math.floor(Date.now()/1000)).catch(()=>{});</script></main></body></html>");
  return h;
}

void handleRoot() {
  if (!requireAuth()) return;
  server.send(200, "text/html; charset=utf-8", makeWebPage());
}

void handleStatus() {
  if (!requireAuth()) return;
  String json = "{\"ap\":\"" + htmlEscape(activeApSsid()) + "\",\"ip\":\"" + WiFi.softAPIP().toString() + "\",\"sta\":\"" + String(WiFi.status() == WL_CONNECTED ? "connected" : "not connected") + "\",\"battery\":" + String(batteryPercent < 0 ? 0 : batteryPercent) + "}";
  server.send(200, "application/json", json);
}

void handleSave() {
  if (!requireAuth()) return;
  for (int i = 0; i < 30; ++i) {
    char key[8]; snprintf(key, sizeof(key), "p%02d", i);
    if (server.hasArg(key)) {
      String value = server.arg(key); value.trim();
      if (value.length() > 32) value = value.substring(0, 32);
      saveProfile(i, value);
    }
  }
  if (server.hasArg("active")) {
    int a = server.arg("active").toInt();
    if (a >= 0 && a < 30) { activeProfile = a; prefs.putInt("active", activeProfile); }
  }
  if (server.hasArg("apPass") && server.arg("apPass").length() >= 8) {
    apPass = server.arg("apPass"); prefs.putString("appass", apPass);
  }
  if (server.hasArg("webPass") && server.arg("webPass").length() >= 8) {
    webPass = server.arg("webPass"); prefs.putString("webpass", webPass);
  }
  if (server.hasArg("clearSta")) {
    staSsid = ""; staPass = ""; prefs.putString("stassid", ""); prefs.putString("stapass", "");
  } else {
    if (server.hasArg("staSsid")) { staSsid = server.arg("staSsid"); staSsid.trim(); prefs.putString("stassid", staSsid); }
    if (server.hasArg("staPass") && server.arg("staPass").length() > 0) { staPass = server.arg("staPass"); prefs.putString("stapass", staPass); }
  }
  server.send(200, "text/html; charset=utf-8", F("<!doctype html><meta name='viewport' content='width=device-width'><body style='background:#080d16;color:#eaf3ff;font:16px system-ui;padding:24px'><h2>Pengaturan tersimpan.</h2><p>Perangkat akan restart dalam beberapa saat. Sambungkan kembali ke Wi-Fi DEVLIN.</p></body>"));
  delay(350);
  ESP.restart();
}

void handleRestart() {
  if (!requireAuth()) return;
  server.send(200, "text/plain", "Restarting DEVLIN OS...");
  delay(250);
  ESP.restart();
}

void setupWeb() {
  server.on("/", HTTP_GET, handleRoot);
  server.on("/save", HTTP_POST, handleSave);
  server.on("/status", HTTP_GET, handleStatus);
  server.on("/settime", HTTP_GET, handleSetTime);
  server.on("/restart", HTTP_GET, handleRestart);
  server.onNotFound([]() {
    if (!requireAuth()) return;
    server.sendHeader("Location", "/", true);
    server.send(302, "text/plain", "Go to /.");
  });
  server.begin();
}

void updateKeys() {
  uint32_t now = millis();
  for (auto &k : keys) {
    bool raw = digitalRead(k.pin);
    if (raw != k.lastRaw) { k.lastRaw = raw; k.lastChange = now; }
    if ((now - k.lastChange) > 25 && raw != k.stable) {
      k.stable = raw;
      if (k.stable == LOW) {
        k.pressedEvent = true;
        k.downAt = now;
        k.longSent = false;
        lastInteraction = now;
      }
    }
    if (k.stable == LOW && !k.longSent && now - k.downAt > 800) {
      k.longEvent = true;
      k.longSent = true;
    }
  }
}

bool takePress(KeyId id) {
  bool v = keys[id].pressedEvent;
  keys[id].pressedEvent = false;
  return v;
}
bool takeLong(KeyId id) {
  bool v = keys[id].longEvent;
  keys[id].longEvent = false;
  return v;
}
bool takeConfirmOrStart() {
  bool c = takePress(K_CONFIRM);
  bool s = takePress(K_START);
  return c || s;
}
bool anyPressPending() {
  for (auto &k : keys) if (k.pressedEvent) return true;
  return false;
}

void updateBattery() {
  if (millis() - lastBatteryRead < 1500) return;
  lastBatteryRead = millis();
  uint32_t mv = (uint32_t)((analogRead(A0) / 1023.0f) * 3200.0f); // D1 mini A0 full-scale approx 3.2 V
  batteryVoltage = (mv / 1000.0f) * 2.0f; // 100k:100k divider
  if (batteryVoltage < 2.5f || batteryVoltage > 5.0f) { batteryPercent = -1; return; }
  float v = batteryVoltage;
  int p;
  if (v <= 3.30f) p = 0;
  else if (v < 3.50f) p = (int)(5 + (v - 3.30f) * 50.0f);
  else if (v < 3.70f) p = (int)(15 + (v - 3.50f) * 100.0f);
  else if (v < 3.85f) p = (int)(35 + (v - 3.70f) * 166.7f);
  else if (v < 4.00f) p = (int)(60 + (v - 3.85f) * 133.3f);
  else if (v < 4.20f) p = (int)(80 + (v - 4.00f) * 100.0f);
  else p = 100;
  batteryPercent = constrain(p, 0, 100);
}

void drawBattery() {
  display.setTextSize(1);
  if (batteryPercent >= 0) {
    display.setCursor(82, 0); display.print(batteryPercent); display.print('%');
    display.drawRect(105, 1, 19, 7, SSD1306_WHITE);
    display.fillRect(124, 3, 2, 3, SSD1306_WHITE);
    int fill = map(batteryPercent, 0, 100, 0, 15);
    if (fill > 0) display.fillRect(107, 3, fill, 3, SSD1306_WHITE);
  } else {
    display.setCursor(88, 0); display.print("BAT?");
  }
}

void drawHeader() {
  display.setTextSize(1); display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0); display.print("DEVLIN OS");
  drawBattery();
  display.drawFastHLine(0, 9, 128, SSD1306_WHITE);
}

void drawLogo(int x, int y, int color) {
  display.drawTriangle(x, y + 8, x + 8, y, x + 16, y + 8, color);
  display.drawLine(x + 4, y + 8, x + 8, y + 3, color);
  display.drawLine(x + 8, y + 3, x + 12, y + 8, color);
}

void drawLogo(int x, int y, int color);

void bootAnimation() {
  if (!oledOk) return;
  if (!animationsEnabled) {
    display.clearDisplay();
    drawLogo(56, 5, SSD1306_WHITE);
    display.setTextColor(SSD1306_WHITE); display.setTextSize(2);
    display.setCursor(15, 22); display.print("DEVLIN");
    display.setTextSize(1); display.setCursor(20, 42); display.print("LAUNCHER V1.1");
    display.setCursor(38, 55); display.print("READY");
    display.display(); delay(350); return;
  }
  for (int frame = 0; frame <= 34; ++frame) {
    display.clearDisplay();
    int bob = (frame % 8 < 4) ? frame % 4 : 7 - (frame % 8);
    int logoX = 55 + (int)(sin(frame * 0.34f) * 10.0f);
    drawLogo(logoX, 3 + bob, SSD1306_WHITE);
    // Tiny orbiting pixels give the monochrome OLED a playful boot animation.
    for (int i = 0; i < 5; ++i) {
      int px = (frame * 5 + i * 25) % 126;
      int py = 8 + ((frame + i * 3) % 7);
      display.drawPixel(px, py, SSD1306_WHITE);
    }
    display.setTextColor(SSD1306_WHITE); display.setTextSize(2);
    display.setCursor(15 + ((frame / 5) % 2), 20); display.print("DEVLIN");
    display.setTextSize(1); display.setCursor(20, 40); display.print("LAUNCHER V1.1");
    display.drawRect(15, 53, 98, 7, SSD1306_WHITE);
    int fill = (frame * 94) / 34;
    display.fillRect(17, 55, fill, 3, SSD1306_WHITE);
    if ((frame / 4) % 2 == 0) { display.setCursor(42, 45); display.print("BOOTING..."); }
    display.display();
    delay(35);
  }
  // A little smiley bounce before entering the main menu.
  for (int frame = 0; frame < 6; ++frame) {
    display.clearDisplay();
    drawLogo(56, 4 + (frame % 3), SSD1306_WHITE);
    display.setTextColor(SSD1306_WHITE); display.setTextSize(1);
    display.setCursor(20, 25); display.print("WELCOME TO DEVLIN");
    display.drawCircle(64, 45, 7, SSD1306_WHITE);
    display.fillCircle(61, 43, 1, SSD1306_WHITE); display.fillCircle(67, 43, 1, SSD1306_WHITE);
    display.drawLine(61, 47, 64, 49, SSD1306_WHITE); display.drawLine(64, 49, 67, 47, SSD1306_WHITE);
    display.display(); delay(45);
  }
}

enum Screen { SCR_MENU, SCR_CLOCK, SCR_WIFI_SCAN, SCR_GAMES, SCR_CALC, SCR_STOPWATCH, SCR_SETTINGS, SCR_NETWORK, SCR_SCORES, SCR_ABOUT, SCR_BLOCK, SCR_BREAKER, SCR_ONELINE, SCR_TTT, SCR_SNAKE, SCR_PONG, SCR_JUMPER, SCR_REACTION, SCR_SIMON, SCR_DODGE };
Screen screen = SCR_MENU;
int menuIndex = 0, gameMenuIndex = 0;
uint32_t clockTransitionStart = 0;
bool transitionClock = false;

const char *mainItems[] = {"Wi-Fi Scanner", "Game Center", "Calculator", "Stopwatch", "Network Setup", "High Scores", "Settings", "About DEVLIN"};
const int MAIN_COUNT = sizeof(mainItems) / sizeof(mainItems[0]);
const char *gameItems[] = {"Block Blast", "Block Breaker", "One Line", "Tic-Tac-Toe", "Snake", "Pong", "Pixel Jumper", "Reaction Tap", "Simon Memory", "Dodge Drop", "Back"};
const int GAME_COUNT = sizeof(gameItems) / sizeof(gameItems[0]);
int scoresPage = 0;

void drawIcon(int idx, int x, int y, int color) {
  switch (idx % 6) {
    case 0:
      display.drawCircle(x + 6, y + 7, 1, color); display.drawLine(x + 2, y + 5, x + 4, y + 3, color); display.drawLine(x + 4, y + 3, x + 8, y + 3, color); display.drawLine(x + 8, y + 3, x + 10, y + 5, color); display.drawLine(x, y + 3, x + 3, y, color); display.drawLine(x + 3, y, x + 9, y, color); display.drawLine(x + 9, y, x + 12, y + 3, color); break;
    case 1:
      display.drawRoundRect(x, y + 1, 14, 10, 2, color); display.drawLine(x + 3, y + 4, x + 7, y + 4, color); display.drawLine(x + 5, y + 2, x + 5, y + 6, color); display.fillCircle(x + 10, y + 4, 1, color); display.fillCircle(x + 11, y + 7, 1, color); break;
    case 2:
      display.drawRoundRect(x + 1, y, 12, 12, 2, color); display.drawFastHLine(x + 4, y + 3, 6, color); display.drawFastHLine(x + 4, y + 6, 6, color); display.drawFastHLine(x + 4, y + 9, 6, color); break;
    case 3:
      display.drawRect(x + 1, y, 12, 12, color); display.drawLine(x + 4, y + 3, x + 10, y + 3, color); display.drawLine(x + 4, y + 6, x + 10, y + 6, color); display.drawLine(x + 4, y + 9, x + 8, y + 9, color); break;
    case 4:
      display.drawTriangle(x + 1, y + 11, x + 7, y, x + 13, y + 11, color); display.drawPixel(x + 7, y + 7, color); break;
    default:
      display.drawCircle(x + 7, y + 6, 5, color); display.drawCircle(x + 7, y + 6, 2, color); break;
  }
}

void drawMenuList(const char **items, int count, int selected, const char *titleText) {
  display.clearDisplay(); drawHeader();
  display.setTextColor(SSD1306_WHITE); display.setTextSize(1); display.setCursor(0, 11); display.print(titleText);
  int start = (selected / 4) * 4;
  for (int row = 0; row < 4; ++row) {
    int idx = start + row; if (idx >= count) break;
    int y = 21 + row * 10;
    bool sel = idx == selected;
    uint32_t anim = animationsEnabled ? millis() / 170 : 0;
    int bob = (animationsEnabled && sel) ? ((anim % 3 == 0) ? -1 : ((anim % 3 == 1) ? 0 : 1)) : 0;
    if (sel) display.fillRoundRect(0, y - 1, 128, 10, 2, SSD1306_WHITE);
    int col = sel ? SSD1306_BLACK : SSD1306_WHITE;
    drawIcon(idx, 2, y - 1 + bob, col);
    display.setTextColor(col); display.setCursor(21, y); display.print(items[idx]);
    if (sel) {
      display.fillTriangle(119, y + 2, 124, y + 4, 119, y + 7, SSD1306_BLACK);
      if (animationsEnabled) {
        int sx = 108 + (anim % 3) * 3;
        display.drawPixel(sx, y + 1, SSD1306_BLACK);
        if ((anim % 2) == 0) display.drawPixel(sx - 2, y + 7, SSD1306_BLACK);
      }
    }
  }
  display.setTextColor(SSD1306_WHITE); display.setCursor(0, 59); display.print("UP/DN MOVE  OK OPEN");
  if (animationsEnabled && (millis() / 250) % 2 == 0) { display.drawPixel(123, 13, SSD1306_WHITE); display.drawPixel(119, 15, SSD1306_WHITE); }
  display.display();
}

void animateClockTransition() {
  if (!animationsEnabled) return;
  // Sliding monochrome curtain with a moving sparkle.
  for (int x = 0; x < 128; x += 16) {
    display.fillRect(x, 10, 16, 54, SSD1306_WHITE);
    display.drawCircle(min(126, x + 8), 36, 3, SSD1306_BLACK);
    display.display(); delay(14);
  }
  for (int x = 0; x < 128; x += 16) {
    display.fillRect(x, 10, 16, 54, SSD1306_BLACK);
    display.drawPixel((x + 13) % 128, 18 + (x % 30), SSD1306_WHITE);
    display.display(); delay(10);
  }
}

void drawClock() {
  display.clearDisplay(); drawHeader();
  display.setTextColor(SSD1306_WHITE);
  if (timeIsValid()) {
    time_t now = time(nullptr); struct tm t; localtime_r(&now, &t);
    char hm[8], sec[8], date[24];
    strftime(hm, sizeof(hm), "%H:%M", &t); strftime(sec, sizeof(sec), "%S", &t); strftime(date, sizeof(date), "%a, %d %b %Y", &t);
    display.setTextSize(2); display.setCursor(14, 18); display.print(hm);
    display.setTextSize(1); display.setCursor(91, 25); display.print(":"); display.print(sec);
    display.setCursor(16, 43); display.print(date);
    display.setCursor(29, 55); display.print("WIB  ·  DEVLIN");
    // Small animated mascot and twinkling star at the edge of the clock screen.
    int bounce = animationsEnabled ? (millis() / 220) % 2 : 0;
    display.drawCircle(7, 44 - bounce, 4, SSD1306_WHITE);
    display.drawPixel(5, 43 - bounce, SSD1306_WHITE); display.drawPixel(9, 43 - bounce, SSD1306_WHITE);
    display.drawLine(5, 46 - bounce, 7, 47 - bounce, SSD1306_WHITE); display.drawLine(7, 47 - bounce, 9, 46 - bounce, SSD1306_WHITE);
    if (animationsEnabled) {
      int starY = 13 + ((millis() / 90) % 48);
      display.drawPixel(125, starY, SSD1306_WHITE);
      if ((millis() / 300) % 2 == 0) display.drawPixel(121, starY + 2, SSD1306_WHITE);
    }
  } else {
    display.setTextSize(1); display.setCursor(15, 18); display.print("WIB CLOCK NOT SYNCED");
    display.setCursor(7, 32); display.print("Connect router in web portal");
    display.setCursor(13, 45); display.print("or open portal to sync phone");
    display.setCursor(19, 56); display.print("192.168.4.1");
  }
  display.display();
}

void drawWifiScan() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE); display.setCursor(0, 11); display.print("WI-FI SCANNER");
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_RUNNING) { display.setCursor(0, 25); display.print("Scanning"); int dots = (millis() / 240) % 4; for (int i = 0; i < dots; ++i) display.print("."); }
  else if (n < 0) { display.setCursor(0, 25); display.print("Press OK to scan"); }
  else if (n == 0) { display.setCursor(0, 25); display.print("No networks found"); }
  else {
    int shown = min(n, 4);
    for (int i = 0; i < shown; ++i) {
      int y = 22 + i * 9;
      String s = WiFi.SSID(i); if (s.length() > 14) s = s.substring(0, 14);
      display.setCursor(0, y); display.print(s);
      display.setCursor(96, y); display.print(WiFi.RSSI(i));
    }
  }
  display.setCursor(0, 58); display.print("OK RESCAN   BACK EXIT"); display.display();
}

void doScan() {
  WiFi.scanDelete();
  WiFi.scanNetworks(true, true);
}

void drawNetwork() {
  display.clearDisplay(); drawHeader(); display.setTextColor(SSD1306_WHITE); display.setTextSize(1); display.setCursor(0, 12); display.print("NETWORK SETUP");
  display.setCursor(0, 25); display.print("AP: "); String s = activeApSsid(); if (s.length() > 17) s = s.substring(0, 17); display.print(s);
  display.setCursor(0, 36); display.print("IP: 192.168.4.1");
  display.setCursor(0, 46); display.print("Router: "); display.print(WiFi.status() == WL_CONNECTED ? "CONNECTED" : "OFFLINE");
  int pulse = (millis() / 220) % 4;
  for (int i = 0; i < 4; ++i) display.fillRect(102 + i * 5, 44 - (i <= pulse ? (i + 1) * 3 : 0), 3, (i <= pulse ? (i + 1) * 3 : 2), SSD1306_WHITE);
  display.setCursor(0, 57); display.print("OK/BACK RETURN"); display.display();
}

void drawScores() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE); display.setCursor(0, 12); display.print("HIGH SCORES "); display.print(scoresPage + 1); display.print("/3");
  if (scoresPage == 0) {
    display.setCursor(0, 25); display.print("Block Blast: "); display.print(prefs.getUInt("hsblock", 0));
    display.setCursor(0, 36); display.print("Block Breaker: "); display.print(prefs.getUInt("hsbreak", 0));
    display.setCursor(0, 47); display.print("One Line: "); uint32_t best = prefs.getUInt("hsoneline", 0); if (best == 0) display.print("--"); else { display.print(best / 1000); display.print("s"); }
  } else if (scoresPage == 1) {
    display.setCursor(0, 25); display.print("Snake: "); display.print(prefs.getUInt("hssnake", 0));
    display.setCursor(0, 36); display.print("Pong hits: "); display.print(prefs.getUInt("hspong", 0));
    display.setCursor(0, 47); display.print("Pixel Jumper: "); display.print(prefs.getUInt("hsjumper", 0));
  } else {
    display.setCursor(0, 25); display.print("Simon level: "); display.print(prefs.getUInt("hssimon", 0));
    display.setCursor(0, 36); display.print("Dodge score: "); display.print(prefs.getUInt("hsdodge", 0));
    display.setCursor(0, 47); display.print("Reaction: "); uint32_t best = prefs.getUInt("hsreact", 0); if (best) { display.print(best); display.print("ms"); } else display.print("--");
  }
  if ((millis() / 260) % 2 == 0) display.drawPixel(122, 13, SSD1306_WHITE);
  display.setCursor(0, 58); display.print("UP/DN PAGE  BACK EXIT"); display.display();
}

void drawAbout() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE); display.setCursor(0, 13); display.print("DEVLIN LAUNCHER V1.1");
  display.setCursor(0, 26); display.print("Board: ESP8266 4MB");
  display.setCursor(0, 36); display.print("OLED: SSD1306 128x64");
  display.setCursor(0, 46); display.print("10 GAMES + WEB + TOOLS");
  int bx = 106 + (int)((millis() / 140) % 5);
  display.drawCircle(bx, 31, 5, SSD1306_WHITE); display.drawPixel(bx - 2, 30, SSD1306_WHITE); display.drawPixel(bx + 2, 30, SSD1306_WHITE);
  display.setCursor(0, 58); display.print("BACK TO MENU"); display.display();
}

// ---------------- BLOCK PUZZLE (original line-clearing block game) ----------------
uint8_t blockBoard[8][8];
int blockX = 2, blockY = 2, blockPiece = 0;
uint32_t blockScore = 0;
bool blockOver = false;
const int pieceCount = 7;
const int8_t pieceCells[pieceCount][4][2] = {
  {{0,0},{1,0},{2,0},{3,0}}, // line
  {{0,0},{1,0},{0,1},{1,1}}, // square
  {{0,0},{0,1},{0,2},{1,2}}, // L
  {{0,0},{1,0},{2,0},{1,1}}, // T
  {{0,0},{1,0},{1,1},{2,1}}, // Z
  {{1,0},{1,1},{1,2},{0,2}}, // reverse L
  {{1,0},{2,0},{0,1},{1,1}}  // S
};

void startBlockGame() {
  memset(blockBoard, 0, sizeof(blockBoard)); blockX = 2; blockY = 2; blockPiece = random(pieceCount); blockScore = 0; blockOver = false;
}

int blockPieceWidth() {
  int w = 1;
  for (int i = 0; i < 4; ++i) w = max(w, (int)pieceCells[blockPiece][i][0] + 1);
  return w;
}
int blockPieceHeight() {
  int h = 1;
  for (int i = 0; i < 4; ++i) h = max(h, (int)pieceCells[blockPiece][i][1] + 1);
  return h;
}
bool canPlacePiece(int x, int y) {
  for (int i = 0; i < 4; ++i) {
    int xx = x + pieceCells[blockPiece][i][0], yy = y + pieceCells[blockPiece][i][1];
    if (xx < 0 || xx >= 8 || yy < 0 || yy >= 8 || blockBoard[yy][xx]) return false;
  }
  return true;
}

void updateBlockHighScore() {
  uint32_t hs = prefs.getUInt("hsblock", 0);
  if (blockScore > hs) prefs.putUInt("hsblock", blockScore);
}

void placeBlockPiece() {
  if (blockOver) { startBlockGame(); return; }
  if (!canPlacePiece(blockX, blockY)) return;
  for (int i = 0; i < 4; ++i) blockBoard[blockY + pieceCells[blockPiece][i][1]][blockX + pieceCells[blockPiece][i][0]] = 1;
  blockScore += 4;
  bool fullRows[8] = {false, false, false, false, false, false, false, false};
  bool fullCols[8] = {false, false, false, false, false, false, false, false};
  int cleared = 0;
  for (int y = 0; y < 8; ++y) {
    fullRows[y] = true;
    for (int x = 0; x < 8; ++x) if (!blockBoard[y][x]) { fullRows[y] = false; break; }
    if (fullRows[y]) cleared++;
  }
  for (int x = 0; x < 8; ++x) {
    fullCols[x] = true;
    for (int y = 0; y < 8; ++y) if (!blockBoard[y][x]) { fullCols[x] = false; break; }
    if (fullCols[x]) cleared++;
  }
  // Block-puzzle behavior: completed rows/columns disappear in place; other blocks do not fall.
  for (int y = 0; y < 8; ++y) for (int x = 0; x < 8; ++x) {
    if (fullRows[y] || fullCols[x]) blockBoard[y][x] = 0;
  }
  blockScore += cleared * 100;
  blockPiece = (blockPiece + 1) % pieceCount;
  blockX = 2; blockY = 2;
  // Game over only when the next shape has no valid placement, not merely when a cell is occupied.
  bool placeable = false;
  for (int y = 0; y < 8 && !placeable; ++y) {
    for (int x = 0; x < 8; ++x) {
      if (canPlacePiece(x, y)) { placeable = true; break; }
    }
  }
  if (!placeable) blockOver = true;
  updateBlockHighScore();
}

void drawBlockGame() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE); display.setCursor(0, 11); display.print("BLOCK BLAST"); display.setCursor(80, 11); display.print("B< S>");
  const int cell = 5, ox = 2, oy = 22;
  for (int y = 0; y < 8; ++y) for (int x = 0; x < 8; ++x) {
    int px = ox + x * cell, py = oy + y * cell;
    if (blockBoard[y][x]) display.fillRect(px, py, 5, 5, SSD1306_WHITE); else display.drawRect(px, py, 5, 5, SSD1306_WHITE);
  }
  if (!blockOver) {
    for (int i = 0; i < 4; ++i) {
      int xx = blockX + pieceCells[blockPiece][i][0], yy = blockY + pieceCells[blockPiece][i][1];
      if (xx >= 0 && xx < 8 && yy >= 0 && yy < 8) display.drawRect(ox + xx * cell, oy + yy * cell, 5, 5, SSD1306_INVERSE);
    }
  }
  display.setCursor(54, 24); display.print("SCORE"); display.setCursor(54, 34); display.print(blockScore);
  display.setCursor(54, 44); display.print("BEST"); display.setCursor(54, 54); display.print(prefs.getUInt("hsblock", 0));
  if (blockOver) { display.fillRect(4, 28, 120, 17, SSD1306_BLACK); display.drawRect(4, 28, 120, 17, SSD1306_WHITE); display.setCursor(20, 33); display.print("NO MOVE: OK RETRY"); }
  display.display();
}

// ---------------- BLOCK BREAKER ----------------
bool bricks[5][10];
float ballX = 64, ballY = 48, ballVX = 1.3f, ballVY = -1.5f;
int paddleX = 53, lives = 3;
bool ballLaunched = false, breakerOver = false;
uint32_t breakerScore = 0, lastBallTick = 0;
void startBreaker() {
  for (int r = 0; r < 5; ++r) for (int c = 0; c < 10; ++c) bricks[r][c] = true;
  ballX = 64; ballY = 49; ballVX = 1.2f; ballVY = -1.5f; paddleX = 53; lives = 3; ballLaunched = false; breakerOver = false; breakerScore = 0;
}
void saveBreakerScore() { uint32_t hs = prefs.getUInt("hsbreak", 0); if (breakerScore > hs) prefs.putUInt("hsbreak", breakerScore); }
void tickBreaker() {
  if (screen != SCR_BREAKER || breakerOver || !ballLaunched || millis() - lastBallTick < 28) return;
  lastBallTick = millis(); ballX += ballVX; ballY += ballVY;
  if (ballX < 1 || ballX > 126) ballVX = -ballVX;
  if (ballY < 11) ballVY = fabs(ballVY);
  if (ballY >= 55 && ballY <= 59 && ballX >= paddleX && ballX <= paddleX + 22 && ballVY > 0) { ballVY = -fabs(ballVY); ballVX = ((ballX - (paddleX + 11)) / 11.0f) * 2.0f; }
  int bc = (int)(ballX - 3) / 12, br = (int)(ballY - 12) / 5;
  if (br >= 0 && br < 5 && bc >= 0 && bc < 10 && bricks[br][bc]) { bricks[br][bc] = false; ballVY = -ballVY; breakerScore += 10; }
  if (ballY > 64) {
    lives--; if (lives <= 0) { breakerOver = true; saveBreakerScore(); }
    else { ballX = paddleX + 11; ballY = 52; ballLaunched = false; }
  }
  bool left = false; for (int r = 0; r < 5; ++r) for (int c = 0; c < 10; ++c) if (bricks[r][c]) left = true;
  if (!left) { breakerOver = true; saveBreakerScore(); }
}
void drawBreaker() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE); display.setCursor(0, 11); display.print("BLOCK BREAKER");
  for (int r = 0; r < 5; ++r) for (int c = 0; c < 10; ++c) if (bricks[r][c]) display.fillRect(3 + c * 12, 21 + r * 5, 9, 3, SSD1306_WHITE);
  display.fillRect(paddleX, 58, 22, 3, SSD1306_WHITE); display.fillCircle((int)ballX, (int)ballY, 1, SSD1306_WHITE);
  display.setCursor(0, 15); display.print("S:"); display.print(breakerScore); display.setCursor(82, 15); display.print("L:"); display.print(lives);
  if (!ballLaunched && !breakerOver) { display.fillRect(25, 39, 78, 10, SSD1306_BLACK); display.setCursor(27, 40); display.print("OK TO LAUNCH"); }
  if (breakerOver) { display.fillRect(10, 36, 108, 15, SSD1306_BLACK); display.drawRect(10, 36, 108, 15, SSD1306_WHITE); display.setCursor(17, 40); display.print("GAME OVER - OK AGAIN"); }
  display.display();
}

// ---------------- ONE LINE ----------------
int onePos = 0, onePath[9], oneCount = 0;
bool oneVisited[9], oneWon = false;
uint32_t oneStart = 0;
void startOneLine() { memset(oneVisited, 0, sizeof(oneVisited)); onePos = 0; oneCount = 1; onePath[0] = 0; oneVisited[0] = true; oneWon = false; oneStart = millis(); }
void moveOneLine(int dx, int dy) {
  if (oneWon) return;
  int x = onePos % 3, y = onePos / 3, nx = x + dx, ny = y + dy;
  if (nx < 0 || nx > 2 || ny < 0 || ny > 2) return;
  int next = ny * 3 + nx;
  if (oneVisited[next]) return;
  onePos = next; oneVisited[next] = true; onePath[oneCount++] = next;
  if (oneCount == 9) {
    oneWon = true; uint32_t elapsed = millis() - oneStart; uint32_t best = prefs.getUInt("hsoneline", 0);
    if (best == 0 || elapsed < best) prefs.putUInt("hsoneline", elapsed);
  }
}
void drawOneLine() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 11); display.print("ONE LINE");
  display.setCursor(0, 24); display.print("VISITED "); display.print(oneCount); display.print("/9");
  display.setCursor(0, 37); display.print("DIR=TRACE");
  display.setCursor(0, 47); display.print("OK=UNDO");
  const int ox = 78, oy = 25, gap = 13;
  for (int i = 1; i < oneCount; ++i) {
    int a = onePath[i - 1], b = onePath[i];
    display.drawLine(ox + (a % 3) * gap, oy + (a / 3) * gap, ox + (b % 3) * gap, oy + (b / 3) * gap, SSD1306_WHITE);
  }
  for (int i = 0; i < 9; ++i) {
    int x = ox + (i % 3) * gap, y = oy + (i / 3) * gap;
    if (oneVisited[i]) display.fillCircle(x, y, 2, SSD1306_WHITE); else display.drawCircle(x, y, 2, SSD1306_WHITE);
  }
  display.drawCircle(ox + (onePos % 3) * gap, oy + (onePos / 3) * gap, 4 + ((millis() / 240) % 2), SSD1306_INVERSE);
  display.setCursor(0, 58); display.print(oneWon ? "SOLVED! OK REPLAY" : "HOLD BACK TO EXIT");
  display.display();
}

// ---------------- TIC TAC TOE ----------------
int ttt[9], tttCursor = 0, tttPlayer = 1, tttWinner = 0;
void startTtt() { memset(ttt, 0, sizeof(ttt)); tttCursor = 0; tttPlayer = 1; tttWinner = 0; }
int checkTtt() {
  const int lines[8][3] = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
  for (auto &ln : lines) if (ttt[ln[0]] && ttt[ln[0]] == ttt[ln[1]] && ttt[ln[1]] == ttt[ln[2]]) return ttt[ln[0]];
  for (int i = 0; i < 9; ++i) if (!ttt[i]) return 0;
  return 3;
}
void drawTtt() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 11); display.print("TIC-TAC-TOE");
  const int ox = 2, oy = 22, cell = 12;
  for (int i = 1; i < 3; ++i) {
    display.drawFastVLine(ox + i * cell, oy, cell * 3, SSD1306_WHITE);
    display.drawFastHLine(ox, oy + i * cell, cell * 3, SSD1306_WHITE);
  }
  for (int i = 0; i < 9; ++i) {
    int x = ox + (i % 3) * cell, y = oy + (i / 3) * cell;
    if (ttt[i] == 1) {
      display.drawLine(x + 3, y + 3, x + 9, y + 9, SSD1306_WHITE);
      display.drawLine(x + 9, y + 3, x + 3, y + 9, SSD1306_WHITE);
    } else if (ttt[i] == 2) display.drawCircle(x + 6, y + 6, 3, SSD1306_WHITE);
  }
  int cx = ox + (tttCursor % 3) * cell, cy = oy + (tttCursor / 3) * cell;
  if ((millis() / 220) % 2 == 0) display.drawRect(cx + 1, cy + 1, cell - 2, cell - 2, SSD1306_INVERSE);
  else display.drawCircle(cx + 6, cy + 6, 5, SSD1306_INVERSE);
  display.setCursor(43, 24); display.print("2 PLAYERS");
  display.setCursor(43, 35);
  if (tttWinner == 1) display.print("X WINS!");
  else if (tttWinner == 2) display.print("O WINS!");
  else if (tttWinner == 3) display.print("DRAW!");
  else { display.print("TURN: "); display.print(tttPlayer == 1 ? 'X' : 'O'); }
  display.setCursor(43, 46); display.print("DIR MOVE");
  display.setCursor(0, 59); display.print(tttWinner ? "OK/START REPLAY" : "OK PLACE  HOLD B EXIT");
  display.display();
}

// ---------------- SNAKE ----------------
struct SnakePoint { int8_t x; int8_t y; };
SnakePoint snakeBody[112];
int snakeLen = 4, snakeDx = 1, snakeDy = 0, snakeFoodX = 11, snakeFoodY = 3;
bool snakeOver = false;
uint32_t snakeScore = 0, snakeLastTick = 0;
void spawnSnakeFood() {
  if (snakeLen >= 112) { snakeOver = true; return; }
  for (int attempt = 0; attempt < 400; ++attempt) {
    snakeFoodX = random(0, 16); snakeFoodY = random(0, 7);
    bool occupied = false;
    for (int i = 0; i < snakeLen; ++i) {
      if (snakeBody[i].x == snakeFoodX && snakeBody[i].y == snakeFoodY) { occupied = true; break; }
    }
    if (!occupied) return;
  }
  // Defensive fallback: never spin forever if the board has no free cell.
  snakeOver = true;
}
void startSnake() {
  snakeLen = 4; snakeDx = 1; snakeDy = 0; snakeScore = 0; snakeOver = false; snakeLastTick = millis();
  for (int i = 0; i < snakeLen; ++i) { snakeBody[i].x = 7 - i; snakeBody[i].y = 3; }
  spawnSnakeFood();
}
void tickSnake() {
  if (screen != SCR_SNAKE || snakeOver || millis() - snakeLastTick < 180) return;
  snakeLastTick = millis();
  int nx = snakeBody[0].x + snakeDx, ny = snakeBody[0].y + snakeDy;
  bool eat = (nx == snakeFoodX && ny == snakeFoodY);
  if (nx < 0 || nx >= 16 || ny < 0 || ny >= 7) snakeOver = true;
  int limit = snakeLen - (eat ? 0 : 1);
  for (int i = 0; i < limit; ++i) if (snakeBody[i].x == nx && snakeBody[i].y == ny) snakeOver = true;
  if (snakeOver) {
    uint32_t hs = prefs.getUInt("hssnake", 0); if (snakeScore > hs) prefs.putUInt("hssnake", snakeScore);
    return;
  }
  if (eat && snakeLen < 112) snakeLen++;
  for (int i = snakeLen - 1; i > 0; --i) snakeBody[i] = snakeBody[i - 1];
  snakeBody[0].x = nx; snakeBody[0].y = ny;
  if (eat) {
    snakeScore += 10;
    if (snakeLen >= 112) {
      snakeOver = true;
      uint32_t hs = prefs.getUInt("hssnake", 0); if (snakeScore > hs) prefs.putUInt("hssnake", snakeScore);
    } else {
      spawnSnakeFood();
      if (snakeOver) { uint32_t hs = prefs.getUInt("hssnake", 0); if (snakeScore > hs) prefs.putUInt("hssnake", snakeScore); }
    }
  }
}
void drawSnake() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE); display.setCursor(0, 11); display.print("SNAKE "); display.print(snakeScore); display.setCursor(82, 11); display.print("B< S>");
  display.drawRect(15, 17, 98, 44, SSD1306_WHITE);
  for (int i = 0; i < snakeLen; ++i) {
    int x = 17 + snakeBody[i].x * 6, y = 19 + snakeBody[i].y * 6;
    if (i == 0) { display.fillRoundRect(x, y, 5, 5, 1, SSD1306_WHITE); display.drawPixel(x + 1, y + 1, SSD1306_BLACK); }
    else display.fillRect(x, y, 4, 4, SSD1306_WHITE);
  }
  int fx = 17 + snakeFoodX * 6, fy = 19 + snakeFoodY * 6;
  if ((millis() / 180) % 2 == 0) display.fillCircle(fx + 2, fy + 2, 2, SSD1306_WHITE); else display.drawCircle(fx + 2, fy + 2, 2, SSD1306_WHITE);
  if (snakeOver) { display.fillRect(20, 31, 88, 17, SSD1306_BLACK); display.drawRect(20, 31, 88, 17, SSD1306_WHITE); display.setCursor(26, 36); display.print("OVER: OK REPLAY"); }
  display.display();
}
// ---------------- PONG ----------------
int pongPaddleY = 30;
float pongX = 28, pongY = 32, pongVX = 1.5f, pongVY = 1.1f;
bool pongLaunched = false, pongOver = false;
uint32_t pongScore = 0, pongLastTick = 0;
void startPong() { pongPaddleY = 28; pongX = 28; pongY = 32; pongVX = 1.6f; pongVY = 1.1f; pongLaunched = false; pongOver = false; pongScore = 0; pongLastTick = millis(); }
void tickPong() {
  if (screen != SCR_PONG || pongOver || !pongLaunched || millis() - pongLastTick < 22) return;
  pongLastTick = millis(); pongX += pongVX; pongY += pongVY;
  if (pongY < 18 || pongY > 53) pongVY = -pongVY;
  if (pongX < 2) pongVX = fabs(pongVX);
  if (pongX >= 116) {
    if (pongY >= pongPaddleY - 2 && pongY <= pongPaddleY + 12) { pongVX = -fabs(pongVX); pongScore++; pongVY += ((pongY - (pongPaddleY + 7)) * 0.035f); if (pongVY > 2.7f) pongVY = 2.7f; if (pongVY < -2.7f) pongVY = -2.7f; }
    else { pongOver = true; uint32_t hs = prefs.getUInt("hspong", 0); if (pongScore > hs) prefs.putUInt("hspong", pongScore); }
  }
}
void drawPong() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 11); display.print("PONG HITS:"); display.print(pongScore);
  for (int y = 20; y < 54; y += 6) display.drawFastVLine(63, y, 3, SSD1306_WHITE);
  display.fillRoundRect(119, pongPaddleY, 4, 12, 1, SSD1306_WHITE);
  display.fillCircle((int)pongX, (int)pongY, 2, SSD1306_WHITE);
  if (!pongLaunched && !pongOver) { display.fillRect(20, 30, 88, 14, SSD1306_BLACK); display.setCursor(24, 34); display.print("OK/START TO SERVE"); }
  if (pongOver) { display.fillRect(17, 29, 95, 18, SSD1306_BLACK); display.drawRect(17, 29, 95, 18, SSD1306_WHITE); display.setCursor(23, 34); display.print("OUT! OK PLAY AGAIN"); }
  display.setCursor(0, 58); display.print("UP/DN MOVE OK SERVE");
  display.display();
}

// ---------------- PIXEL JUMPER (original mini platform runner) ----------------
float jumperY = 48, jumperVy = 0;
int jumperObstacleX = 128;
bool jumperGrounded = true, jumperOver = false;
uint32_t jumperScore = 0, jumperLastTick = 0;
void startJumper() { jumperY = 48; jumperVy = 0; jumperObstacleX = 128 + random(0, 24); jumperGrounded = true; jumperOver = false; jumperScore = 0; jumperLastTick = millis(); }
void tickJumper() {
  if (screen != SCR_JUMPER || jumperOver || millis() - jumperLastTick < 32) return;
  jumperLastTick = millis();
  if (!jumperGrounded) { jumperY += jumperVy; jumperVy += 0.48f; if (jumperY >= 48) { jumperY = 48; jumperVy = 0; jumperGrounded = true; } }
  jumperObstacleX -= 2;
  if (jumperObstacleX < -8) { jumperObstacleX = 128 + random(12, 40); jumperScore++; uint32_t hs = prefs.getUInt("hsjumper", 0); if (jumperScore > hs) prefs.putUInt("hsjumper", jumperScore); }
  if (jumperObstacleX < 27 && jumperObstacleX + 7 > 17 && jumperY >= 43) { jumperOver = true; uint32_t hs = prefs.getUInt("hsjumper", 0); if (jumperScore > hs) prefs.putUInt("hsjumper", jumperScore); }
}
void drawJumper() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE); display.setCursor(0, 11); display.print("JUMPER"); display.setCursor(42, 11); display.print("S:"); display.print(jumperScore); display.setCursor(94, 11); display.print("JUMP");
  int cloudX = 100 - ((millis() / 90) % 120); display.drawCircle(cloudX, 23, 2, SSD1306_WHITE); display.drawCircle(cloudX + 4, 22, 3, SSD1306_WHITE); display.drawCircle(cloudX + 8, 23, 2, SSD1306_WHITE);
  display.drawFastHLine(0, 58, 128, SSD1306_WHITE);
  int py = (int)jumperY;
  display.fillRoundRect(18, py, 8, 9, 2, SSD1306_WHITE); display.drawPixel(23, py + 2, SSD1306_BLACK); display.drawPixel(20, py + 6, SSD1306_BLACK);
  display.drawLine(20, py + 9, 18, py + 11, SSD1306_WHITE); display.drawLine(24, py + 9, 26, py + 11, SSD1306_WHITE);
  display.fillTriangle(jumperObstacleX, 58, jumperObstacleX + 4, 48, jumperObstacleX + 8, 58, SSD1306_WHITE);
  if (jumperOver) { display.fillRect(22, 29, 84, 18, SSD1306_BLACK); display.drawRect(22, 29, 84, 18, SSD1306_WHITE); display.setCursor(28, 34); display.print("BONK! OK TO RETRY"); }
  display.display();
}
// ---------------- REACTION TAP ----------------
int reactionMode = 0; // 0 wait, 1 go, 2 result, 3 false start
uint32_t reactionStart = 0, reactionGoAt = 0, reactionResult = 0;
uint32_t reactionWait = 2500;
void startReaction() { reactionMode = 0; reactionWait = random(1600, 4600); reactionStart = millis(); reactionGoAt = 0; reactionResult = 0; }
void drawReaction() {
  display.clearDisplay(); drawHeader(); display.setTextColor(SSD1306_WHITE); display.setTextSize(1); display.setCursor(0, 12); display.print("REACTION TAP");
  if (reactionMode == 0) {
    int pulse = (millis() / 180) % 2;
    display.drawCircle(64, 34, 8 + pulse * 2, SSD1306_WHITE); display.drawCircle(64, 34, 3, SSD1306_WHITE);
    display.setCursor(23, 50); display.print("WAIT FOR GO...");
    if (millis() - reactionStart >= reactionWait) { reactionMode = 1; reactionGoAt = millis(); }
  } else if (reactionMode == 1) {
    display.fillCircle(64, 32, 15, SSD1306_WHITE); display.setTextColor(SSD1306_BLACK); display.setTextSize(2); display.setCursor(43, 25); display.print("GO!"); display.setTextColor(SSD1306_WHITE); display.setTextSize(1); display.setCursor(30, 53); display.print("PRESS OK NOW!");
  } else if (reactionMode == 2) {
    display.setTextSize(2); display.setCursor(20, 25); display.print(reactionResult); display.setTextSize(1); display.setCursor(88, 31); display.print("ms");
    uint32_t best = prefs.getUInt("hsreact", 0); display.setCursor(18, 47); display.print("BEST: "); if (best) { display.print(best); display.print("ms"); } else display.print("--"); display.setCursor(8, 58); display.print("OK/START TRY AGAIN");
  } else {
    display.drawCircle(64, 31, 11, SSD1306_WHITE); display.drawLine(57, 24, 71, 38, SSD1306_WHITE); display.drawLine(71, 24, 57, 38, SSD1306_WHITE); display.setCursor(28, 51); display.print("TOO SOON! TRY AGAIN");
  }
  display.display();
}
// ---------------- SIMON MEMORY ----------------
uint8_t simonSeq[20];
int simonLen = 1, simonInput = 0, simonMode = 0, simonLit = -1;
uint32_t simonStarted = 0;
void startSimon() { simonLen = 1; simonInput = 0; simonMode = 0; simonLit = -1; simonSeq[0] = random(0, 4); simonStarted = millis(); }
void tickSimon() {
  if (screen != SCR_SIMON || simonMode != 0) return;
  uint32_t elapsed = millis() - simonStarted;
  int slot = elapsed / 620;
  if (slot >= simonLen) { simonMode = 1; simonLit = -1; simonInput = 0; }
  else simonLit = ((elapsed % 620) < 360) ? simonSeq[slot] : -1;
}
void drawSimon() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE); display.setCursor(0, 11); display.print("SIMON MEMORY  LV:"); display.print(simonLen);
  const char *names[] = {"UP", "DOWN", "LEFT", "RIGHT"};
  const int xs[] = {9, 67, 9, 67}; const int ys[] = {22, 22, 39, 39};
  for (int i = 0; i < 4; ++i) {
    bool lit = (simonLit == i) || (simonMode == 1 && simonInput == i + 99);
    if (lit) display.fillRoundRect(xs[i], ys[i], 51, 13, 3, SSD1306_WHITE); else display.drawRoundRect(xs[i], ys[i], 51, 13, 3, SSD1306_WHITE);
    display.setTextColor(lit ? SSD1306_BLACK : SSD1306_WHITE); display.setCursor(xs[i] + 12, ys[i] + 3); display.print(names[i]);
  }
  display.setTextColor(SSD1306_WHITE); display.setCursor(0, 55);
  if (simonMode == 0) display.print("WATCH THE PATTERN..."); else if (simonMode == 1) { display.print("REPEAT: "); display.print(simonInput); display.print("/"); display.print(simonLen); } else { display.print("WRONG! OK/START RETRY"); }
  display.display();
}
// ---------------- DODGE DROP ----------------
int dodgePlayer = 5, dodgeX[4], dodgeY[4];
bool dodgeActive[4], dodgeOver = false;
uint32_t dodgeScore = 0, dodgeLastTick = 0;
void startDodge() { dodgePlayer = 5; for (int i=0;i<4;i++) { dodgeActive[i] = false; dodgeX[i] = 0; dodgeY[i] = 0; } dodgeOver = false; dodgeScore = 0; dodgeLastTick = millis(); }
void tickDodge() {
  if (screen != SCR_DODGE || dodgeOver || millis() - dodgeLastTick < 210) return;
  dodgeLastTick = millis();
  for (int i=0;i<4;i++) if (dodgeActive[i]) { dodgeY[i]++; if (dodgeY[i] >= 6) { if (dodgeX[i] == dodgePlayer) dodgeOver = true; dodgeActive[i] = false; dodgeScore++; } }
  if (random(0, 100) < 62) for (int i=0;i<4;i++) if (!dodgeActive[i]) { dodgeActive[i] = true; dodgeX[i] = random(0,10); dodgeY[i] = 0; break; }
  if (dodgeOver) { uint32_t hs = prefs.getUInt("hsdodge", 0); if (dodgeScore > hs) prefs.putUInt("hsdodge", dodgeScore); }
}
void drawDodge() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE); display.setCursor(0, 11); display.print("DODGE "); display.print(dodgeScore); display.setCursor(82, 11); display.print("B< S>");
  display.drawRect(13, 18, 102, 43, SSD1306_WHITE);
  for (int i=0;i<4;i++) if (dodgeActive[i]) display.fillRoundRect(16 + dodgeX[i]*10, 20 + dodgeY[i]*6, 6, 5, 1, SSD1306_WHITE);
  int px = 16 + dodgePlayer*10; display.fillTriangle(px, 58, px+4, 52, px+8, 58, SSD1306_WHITE);
  if (dodgeOver) { display.fillRect(19, 31, 91, 17, SSD1306_BLACK); display.drawRect(19, 31, 91, 17, SSD1306_WHITE); display.setCursor(25, 36); display.print("CRASH: OK REPLAY"); }
  display.display();
}
// ---------------- CALCULATOR ----------------
// 5x4 keypad includes digits 0-9, decimal point, four operations, clear, delete, double-zero and sign toggle.
const char *calcKeys[20] = {
  "7", "8", "9", "/", "C",
  "4", "5", "6", "*", "DEL",
  "1", "2", "3", "-", ".",
  "0", "00", "=", "+", "+/-"
};
int calcCursor = 0;
String calcInput = "";
String calcResult = "";

int findCalcOperator(const String &expr) {
  for (int i = 1; i < (int)expr.length(); ++i) {
    char c = expr[i];
    if (c == '+' || c == '-' || c == '*' || c == '/') return i;
  }
  return -1;
}

void evaluateCalc() {
  int opAt = findCalcOperator(calcInput);
  if (opAt < 1 || opAt >= (int)calcInput.length() - 1) {
    calcResult = "Need A op B";
    return;
  }
  char op = calcInput[opAt];
  String left = calcInput.substring(0, opAt);
  String right = calcInput.substring(opAt + 1);
  if (left.length() == 0 || right.length() == 0) { calcResult = "Incomplete"; return; }
  double a = left.toDouble(), b = right.toDouble(), r = 0.0;
  if (op == '+') r = a + b;
  else if (op == '-') r = a - b;
  else if (op == '*') r = a * b;
  else if (op == '/') {
    if (fabs(b) < 0.0000001) { calcResult = "DIV BY ZERO"; return; }
    r = a / b;
  }
  if (!isfinite(r)) { calcResult = "OVERFLOW"; return; }
  calcResult = String(r, 4);
  while (calcResult.indexOf('.') >= 0 && calcResult.endsWith("0")) calcResult.remove(calcResult.length() - 1);
  if (calcResult.endsWith(".")) calcResult.remove(calcResult.length() - 1);
  calcInput = calcResult;
  if (calcInput.length() > 15) calcInput = calcInput.substring(0, 15);
}

bool isCalcOperator(char c) { return c == '+' || c == '-' || c == '*' || c == '/'; }

void toggleCalcSign() {
  if (calcInput.length() == 0) { calcInput = "-"; calcResult = ""; return; }
  int opAt = findCalcOperator(calcInput);
  int operandStart = opAt >= 0 ? opAt + 1 : 0;
  if (operandStart < (int)calcInput.length() && calcInput[operandStart] == '-') {
    calcInput.remove(operandStart, 1);
  } else {
    calcInput = calcInput.substring(0, operandStart) + "-" + calcInput.substring(operandStart);
  }
  calcResult = "";
}

void appendCalcKey(const char *key) {
  String k(key);
  if (k == "C") { calcInput = ""; calcResult = ""; return; }
  if (k == "DEL") { if (calcInput.length()) calcInput.remove(calcInput.length() - 1); calcResult = ""; return; }
  if (k == "+/-") { toggleCalcSign(); return; }
  if (k == "=") { if (calcResult.length() && calcInput == calcResult) return; evaluateCalc(); return; }
  char c = k[0];
  bool isDigit = c >= '0' && c <= '9';
  if (calcResult.length() && (isDigit || c == '.')) { calcInput = ""; calcResult = ""; }
  else if (calcResult.length() && isCalcOperator(c)) {
    bool validResult = calcResult != "DIV BY ZERO" && calcResult != "OVERFLOW" && calcResult != "Need A op B" && calcResult != "Incomplete";
    if (validResult) calcInput = calcResult;
    else calcInput = (c == '-') ? "-" : "";
    calcResult = "";
    if (calcInput == "-" || calcInput.length() == 0) return;
  }
  if (isDigit) {
    if (calcInput.length() < 15) calcInput += k;
    calcResult = "";
    return;
  }
  if (c == '.') {
    int opAt = findCalcOperator(calcInput);
    String operand = opAt >= 0 ? calcInput.substring(opAt + 1) : calcInput;
    if (operand.indexOf('.') >= 0) return;
    if (calcInput.length() == 0 || (calcInput.length() && isCalcOperator(calcInput[calcInput.length() - 1]))) calcInput += "0";
    if (calcInput.length() < 15) calcInput += '.';
    calcResult = "";
    return;
  }
  if (isCalcOperator(c)) {
    if (calcInput.length() == 0) {
      if (c == '-') calcInput = "-";
      return;
    }
    char last = calcInput[calcInput.length() - 1];
    if (isCalcOperator(last)) calcInput[calcInput.length() - 1] = c;
    else if (findCalcOperator(calcInput) < 0 && calcInput.length() < 15) calcInput += c;
    else if (findCalcOperator(calcInput) >= 0) {
      evaluateCalc();
      if (calcResult.length() && calcResult != "DIV BY ZERO" && calcResult != "OVERFLOW" && calcResult != "Need A op B" && calcResult != "Incomplete") {
        calcInput = calcResult + String(c);
        calcResult = "";
      }
    }
  }
}

void selectCalcKey() { appendCalcKey(calcKeys[calcCursor]); }

void drawCalc() {
  display.clearDisplay(); drawHeader();
  display.setTextSize(1); display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 11); display.print("CALCULATOR 5x4");
  display.drawRoundRect(1, 19, 126, 10, 2, SSD1306_WHITE);
  display.setCursor(4, 21);
  String val = calcResult.length() ? calcResult : calcInput;
  if (val.length() > 20) val = val.substring(val.length() - 20);
  display.print(val);
  const int cellW = 25, cellH = 8, gridY = 30;
  for (int i = 0; i < 20; ++i) {
    int col = i % 5, row = i / 5;
    int x = col * cellW, y = gridY + row * cellH;
    bool selected = i == calcCursor;
    if (selected) display.fillRect(x, y, cellW - 1, cellH, SSD1306_WHITE);
    else display.drawRect(x, y, cellW - 1, cellH, SSD1306_WHITE);
    display.setTextColor(selected ? SSD1306_BLACK : SSD1306_WHITE);
    int textW = (int)strlen(calcKeys[i]) * 6;
    display.setCursor(x + max(0, (cellW - textW) / 2), y);
    display.print(calcKeys[i]);
  }
  display.display();
}

// ---------------- STOPWATCH ----------------
uint32_t stopwatchElapsedMs() {
  return stopwatchAccumulated + (stopwatchRunning ? (uint32_t)(millis() - stopwatchStartedAt) : 0U);
}
void resetStopwatch() {
  stopwatchRunning = false; stopwatchStartedAt = 0; stopwatchAccumulated = 0; stopwatchLaps = 0;
}
void drawStopwatch() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 12); display.print("STOPWATCH");
  uint32_t elapsed = stopwatchElapsedMs();
  uint32_t minutes = elapsed / 60000UL;
  uint32_t seconds = (elapsed / 1000UL) % 60UL;
  uint32_t centis = (elapsed / 10UL) % 100UL;
  char buf[16]; snprintf(buf, sizeof(buf), "%02lu:%02lu.%02lu", (unsigned long)minutes, (unsigned long)seconds, (unsigned long)centis);
  display.setTextSize(2); display.setCursor(8, 25); display.print(buf);
  display.setTextSize(1); display.setCursor(0, 47); display.print(stopwatchRunning ? "RUNNING" : "PAUSED"); display.setCursor(75, 47); display.print("LAPS:"); display.print(stopwatchLaps);
  display.setCursor(0, 58); display.print("OK RUN/PAUSE  ST RESET");
  display.display();
}
void processStopwatch() {
  if (takePress(K_BACK)) { screen = SCR_MENU; lastInteraction = millis(); return; }
  if (takePress(K_CONFIRM)) {
    if (stopwatchRunning) { stopwatchAccumulated += millis() - stopwatchStartedAt; stopwatchRunning = false; }
    else { stopwatchStartedAt = millis(); stopwatchRunning = true; }
  }
  if (takePress(K_START)) resetStopwatch();
  if (takePress(K_UP)) stopwatchLaps++;
}

// ---------------- SETTINGS ----------------
void drawSettings() {
  display.clearDisplay(); drawHeader(); display.setTextSize(1); display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 12); display.print("SYSTEM SETTINGS");
  const char *labels[] = {"Animations", "Auto clock 10s"};
  for (int i = 0; i < 2; ++i) {
    int y = 26 + i * 14; bool selected = settingsIndex == i;
    if (selected) display.fillRoundRect(0, y - 1, 128, 12, 2, SSD1306_WHITE);
    display.setTextColor(selected ? SSD1306_BLACK : SSD1306_WHITE);
    display.setCursor(4, y + 1); display.print(labels[i]);
    display.setCursor(100, y + 1); display.print(i == 0 ? (animationsEnabled ? "ON" : "OFF") : (autoClockEnabled ? "ON" : "OFF"));
  }
  display.setTextColor(SSD1306_WHITE); display.setCursor(0, 58); display.print("UP/DN MOVE OK TOGGLE"); display.display();
}
void processSettings() {
  if (takePress(K_BACK)) { screen = SCR_MENU; lastInteraction = millis(); return; }
  bool up = takePress(K_UP), down = takePress(K_DOWN);
  if (up || down) settingsIndex = (settingsIndex + 1) % 2;
  if (takeConfirmOrStart()) {
    if (settingsIndex == 0) { animationsEnabled = !animationsEnabled; prefs.putBool("anim", animationsEnabled); }
    else { autoClockEnabled = !autoClockEnabled; prefs.putBool("autoclk", autoClockEnabled); }
  }
}

void enterScreen(Screen s) {
  screen = s; lastInteraction = millis();
  if (s == SCR_BLOCK) startBlockGame();
  if (s == SCR_BREAKER) startBreaker();
  if (s == SCR_ONELINE) startOneLine();
  if (s == SCR_TTT) startTtt();
  if (s == SCR_SNAKE) startSnake();
  if (s == SCR_PONG) startPong();
  if (s == SCR_JUMPER) startJumper();
  if (s == SCR_REACTION) startReaction();
  if (s == SCR_SIMON) startSimon();
  if (s == SCR_DODGE) startDodge();
  if (s == SCR_CALC) { calcInput = ""; calcResult = ""; calcCursor = 0; }
  if (s == SCR_STOPWATCH) resetStopwatch();
  if (s == SCR_WIFI_SCAN) doScan();
}

void processMenu() {
  if (takePress(K_UP)) { menuIndex = (menuIndex + MAIN_COUNT - 1) % MAIN_COUNT; }
  if (takePress(K_DOWN)) { menuIndex = (menuIndex + 1) % MAIN_COUNT; }
  if (takePress(K_BACK)) { screen = SCR_CLOCK; }
  if (takeConfirmOrStart()) {
    switch (menuIndex) {
      case 0: enterScreen(SCR_WIFI_SCAN); break;
      case 1: screen = SCR_GAMES; gameMenuIndex = 0; lastInteraction = millis(); break;
      case 2: enterScreen(SCR_CALC); break;
      case 3: enterScreen(SCR_STOPWATCH); break;
      case 4: enterScreen(SCR_NETWORK); break;
      case 5: enterScreen(SCR_SCORES); break;
      case 6: enterScreen(SCR_SETTINGS); break;
      default: enterScreen(SCR_ABOUT); break;
    }
  }
  if (autoClockEnabled && screen == SCR_MENU && millis() - lastInteraction > 10000) { animateClockTransition(); screen = SCR_CLOCK; }
}

void processGameMenu() {
  if (takePress(K_UP)) gameMenuIndex = (gameMenuIndex + GAME_COUNT - 1) % GAME_COUNT;
  if (takePress(K_DOWN)) gameMenuIndex = (gameMenuIndex + 1) % GAME_COUNT;
  if (takePress(K_BACK)) { screen = SCR_MENU; lastInteraction = millis(); }
  if (takeConfirmOrStart()) {
    switch (gameMenuIndex) {
      case 0: enterScreen(SCR_BLOCK); break;
      case 1: enterScreen(SCR_BREAKER); break;
      case 2: enterScreen(SCR_ONELINE); break;
      case 3: enterScreen(SCR_TTT); break;
      case 4: enterScreen(SCR_SNAKE); break;
      case 5: enterScreen(SCR_PONG); break;
      case 6: enterScreen(SCR_JUMPER); break;
      case 7: enterScreen(SCR_REACTION); break;
      case 8: enterScreen(SCR_SIMON); break;
      case 9: enterScreen(SCR_DODGE); break;
      default: screen = SCR_MENU; break;
    }
  }
}

void processBlock() {
  // Physical controls in games: UP/DOWN move vertically, BACK(short) left,
  // START right, CONFIRM places the selected shape; hold BACK to leave.
  if (takeLong(K_BACK)) { for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; } screen = SCR_GAMES; lastInteraction = millis(); return; }
  if (blockOver) { takePress(K_BACK); takePress(K_UP); takePress(K_DOWN); if (takeConfirmOrStart()) startBlockGame(); return; }
  if (takePress(K_BACK) && blockX > 0) blockX--;
  if (takePress(K_UP) && blockY > 0) blockY--;
  if (takePress(K_DOWN) && blockY < 8 - blockPieceHeight()) blockY++;
  if (takePress(K_START) && blockX < 8 - blockPieceWidth()) blockX++;
  if (takePress(K_CONFIRM)) placeBlockPiece();
}

void processBreaker() {
  if (takeLong(K_BACK)) { for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; } screen = SCR_GAMES; lastInteraction = millis(); return; }
  if (breakerOver) { takePress(K_BACK); takePress(K_UP); takePress(K_DOWN); if (takeConfirmOrStart()) startBreaker(); return; }
  if (takePress(K_BACK)) paddleX = max(0, paddleX - 7);
  if (takePress(K_START)) paddleX = min(106, paddleX + 7);
  bool launchConfirm = takePress(K_CONFIRM);
  bool launchUp = takePress(K_UP);
  bool launchDown = takePress(K_DOWN);
  bool launch = launchConfirm || launchUp || launchDown;
  if (launch && !ballLaunched) { ballLaunched = true; ballX = paddleX + 11; ballY = 55; lastBallTick = millis(); }
  tickBreaker();
}

void processOneLine() {
  if (takeLong(K_BACK)) { for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; } screen = SCR_GAMES; lastInteraction = millis(); return; }
  if (oneWon) { takePress(K_BACK); takePress(K_UP); takePress(K_DOWN); if (takeConfirmOrStart()) startOneLine(); return; }
  if (takePress(K_BACK)) moveOneLine(-1, 0);
  if (takePress(K_START)) moveOneLine(1, 0);
  if (takePress(K_UP)) moveOneLine(0, -1);
  if (takePress(K_DOWN)) moveOneLine(0, 1);
  if (takePress(K_CONFIRM) && oneCount > 1) {
    oneVisited[onePath[oneCount - 1]] = false;
    oneCount--;
    onePos = onePath[oneCount - 1];
  }
}

void processTtt() {
  if (takeLong(K_BACK)) { for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; } screen = SCR_GAMES; lastInteraction = millis(); return; }
  if (tttWinner) { takePress(K_BACK); takePress(K_UP); takePress(K_DOWN); if (takeConfirmOrStart()) startTtt(); return; }
  int row = tttCursor / 3, col = tttCursor % 3;
  if (takePress(K_UP)) row = (row + 2) % 3;
  if (takePress(K_DOWN)) row = (row + 1) % 3;
  if (takePress(K_BACK)) col = (col + 2) % 3;
  if (takePress(K_START)) col = (col + 1) % 3;
  tttCursor = row * 3 + col;
  if (takePress(K_CONFIRM) && !ttt[tttCursor]) {
    ttt[tttCursor] = tttPlayer; tttWinner = checkTtt();
    if (!tttWinner) tttPlayer = (tttPlayer == 1 ? 2 : 1);
  }
}

void processSnake() {
  if (takeLong(K_BACK)) { for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; } screen = SCR_GAMES; lastInteraction = millis(); return; }
  if (snakeOver) { takePress(K_BACK); takePress(K_UP); takePress(K_DOWN); if (takeConfirmOrStart()) startSnake(); return; }
  if (takePress(K_UP) && snakeDy != 1) { snakeDx = 0; snakeDy = -1; }
  if (takePress(K_DOWN) && snakeDy != -1) { snakeDx = 0; snakeDy = 1; }
  if (takePress(K_BACK) && snakeDx != 1) { snakeDx = -1; snakeDy = 0; }
  if (takePress(K_START) && snakeDx != -1) { snakeDx = 1; snakeDy = 0; }
}

void processPong() {
  if (takeLong(K_BACK)) { for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; } screen = SCR_GAMES; lastInteraction = millis(); return; }
  if (pongOver) { takePress(K_BACK); takePress(K_UP); takePress(K_DOWN); if (takeConfirmOrStart()) startPong(); return; }
  if (takePress(K_UP)) pongPaddleY = max(18, pongPaddleY - 5);
  if (takePress(K_DOWN)) pongPaddleY = min(41, pongPaddleY + 5);
  takePress(K_BACK); // Left is not needed for this vertical-paddle game.
  bool startPressed = takePress(K_START);
  bool confirmPressed = takePress(K_CONFIRM);
  if (startPressed || confirmPressed) {
    if (!pongLaunched) { pongLaunched = true; pongLastTick = millis(); }
  }
}

void processJumper() {
  if (takeLong(K_BACK)) { for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; } screen = SCR_GAMES; lastInteraction = millis(); return; }
  if (jumperOver) { takePress(K_BACK); takePress(K_UP); takePress(K_DOWN); if (takeConfirmOrStart()) startJumper(); return; }
  takePress(K_BACK); // Short BACK has no action in the auto-runner; hold BACK exits.
  bool up = takePress(K_UP), ok = takePress(K_CONFIRM), start = takePress(K_START);
  takePress(K_DOWN);
  if ((up || ok || start) && jumperGrounded) { jumperGrounded = false; jumperVy = -5.2f; }
}

void processReaction() {
  if (takeLong(K_BACK)) { for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; } screen = SCR_GAMES; lastInteraction = millis(); return; }
  takePress(K_BACK);
  bool ok = takePress(K_CONFIRM), start = takePress(K_START);
  takePress(K_UP); takePress(K_DOWN);
  if (start || ((reactionMode == 2 || reactionMode == 3) && ok)) { startReaction(); return; }
  if (ok && reactionMode == 0) reactionMode = 3;
  else if (ok && reactionMode == 1) {
    reactionResult = millis() - reactionGoAt; reactionMode = 2;
    uint32_t best = prefs.getUInt("hsreact", 0); if (!best || reactionResult < best) prefs.putUInt("hsreact", reactionResult);
  }
}

void processSimon() {
  if (takeLong(K_BACK)) { for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; } screen = SCR_GAMES; lastInteraction = millis(); return; }
  bool left = takePress(K_BACK);
  bool up = takePress(K_UP), down = takePress(K_DOWN), ok = takePress(K_CONFIRM), right = takePress(K_START);
  if (simonMode == 2) { if (ok || right) startSimon(); return; }
  if (simonMode != 1) return;
  int input = up ? 0 : (down ? 1 : (left ? 2 : (right ? 3 : -1)));
  if (input < 0) return;
  if (input != simonSeq[simonInput]) {
    simonMode = 2; uint32_t hs = prefs.getUInt("hssimon", 0); if ((uint32_t)(simonLen - 1) > hs) prefs.putUInt("hssimon", simonLen - 1); return;
  }
  simonInput++;
  if (simonInput >= simonLen) {
    uint32_t hs = prefs.getUInt("hssimon", 0); if ((uint32_t)simonLen > hs) prefs.putUInt("hssimon", simonLen);
    if (simonLen >= 19) { simonMode = 2; return; }
    simonSeq[simonLen++] = random(0, 4); simonMode = 0; simonStarted = millis(); simonInput = 0;
  }
}

void processDodge() {
  if (takeLong(K_BACK)) { for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; } screen = SCR_GAMES; lastInteraction = millis(); return; }
  if (dodgeOver) { takePress(K_BACK); takePress(K_UP); takePress(K_DOWN); if (takeConfirmOrStart()) startDodge(); return; }
  if (takePress(K_BACK) && dodgePlayer > 0) dodgePlayer--;
  if (takePress(K_START) && dodgePlayer < 9) dodgePlayer++;
  takePress(K_UP); takePress(K_DOWN); takePress(K_CONFIRM);
}

void processCalc() {
  if (takeLong(K_BACK)) { for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; } screen = SCR_MENU; lastInteraction = millis(); return; }
  if (takePress(K_UP)) calcCursor = (calcCursor + 15) % 20;
  if (takePress(K_DOWN)) calcCursor = (calcCursor + 5) % 20;
  if (takePress(K_BACK)) calcCursor = (calcCursor / 5) * 5 + ((calcCursor + 4) % 5);
  if (takePress(K_START)) calcCursor = (calcCursor / 5) * 5 + ((calcCursor + 1) % 5);
  if (takePress(K_CONFIRM)) selectCalcKey();
}

void processSimpleScreen() {
  if (screen == SCR_SCORES) {
    if (takePress(K_UP)) scoresPage = (scoresPage + 2) % 3;
    if (takePress(K_DOWN)) scoresPage = (scoresPage + 1) % 3;
    bool c = takePress(K_CONFIRM), b = takePress(K_BACK), st = takePress(K_START);
    if (c || b || st) { screen = SCR_MENU; lastInteraction = millis(); }
    return;
  }
  bool confirmPressed = takePress(K_CONFIRM);
  bool backPressed = takePress(K_BACK);
  bool startPressed = takePress(K_START);
  if (screen == SCR_WIFI_SCAN && confirmPressed && !backPressed && !startPressed) { doScan(); return; }
  if (backPressed || startPressed || confirmPressed) { screen = SCR_MENU; lastInteraction = millis(); }
}

void renderScreen() {
  switch (screen) {
    case SCR_MENU: drawMenuList(mainItems, MAIN_COUNT, menuIndex, "MAIN MENU"); break;
    case SCR_CLOCK: drawClock(); break;
    case SCR_WIFI_SCAN: drawWifiScan(); break;
    case SCR_GAMES: drawMenuList(gameItems, GAME_COUNT, gameMenuIndex, "GAME CENTER"); break;
    case SCR_CALC: drawCalc(); break;
    case SCR_STOPWATCH: drawStopwatch(); break;
    case SCR_SETTINGS: drawSettings(); break;
    case SCR_NETWORK: drawNetwork(); break;
    case SCR_SCORES: drawScores(); break;
    case SCR_ABOUT: drawAbout(); break;
    case SCR_BLOCK: drawBlockGame(); break;
    case SCR_BREAKER: drawBreaker(); break;
    case SCR_ONELINE: drawOneLine(); break;
    case SCR_TTT: drawTtt(); break;
    case SCR_SNAKE: drawSnake(); break;
    case SCR_PONG: drawPong(); break;
    case SCR_JUMPER: drawJumper(); break;
    case SCR_REACTION: drawReaction(); break;
    case SCR_SIMON: drawSimon(); break;
    case SCR_DODGE: drawDodge(); break;
  }
}

void setup() {
  // All five buttons are wired active-low to GND and have internal pull-ups enabled.
  // Release Back (D3/GPIO0) and Start (D4/GPIO2) while booting/resetting/flashing.
  randomSeed(ESP.getChipId() ^ micros() ^ analogRead(A0));
  for (auto &k : keys) pinMode(k.pin, INPUT_PULLUP);
  Wire.begin(PIN_SDA, PIN_SCL);
#if defined(DEVLIN_OLED_SH1106)
  oledOk = display.begin(0x3C, true);
  if (!oledOk) oledOk = display.begin(0x3D, true);
#else
  oledOk = display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  if (!oledOk) oledOk = display.begin(SSD1306_SWITCHCAPVCC, 0x3D);
#endif
  loadSettings();
  setenv("TZ", "WIB-7", 1); tzset();
  if (oledOk) bootAnimation();
  startWifi();
  setupWeb();
  requestTimeSync();
  lastInteraction = millis();
  startBlockGame();
  startBreaker();
  startOneLine();
  startTtt();
  screen = SCR_MENU;
}

void loop() {
  server.handleClient();
  updateKeys();
  const bool holdBackScreen = screen == SCR_CALC || screen == SCR_BLOCK || screen == SCR_BREAKER || screen == SCR_ONELINE || screen == SCR_TTT || screen == SCR_SNAKE || screen == SCR_PONG || screen == SCR_JUMPER || screen == SCR_REACTION || screen == SCR_SIMON || screen == SCR_DODGE;
  if (!holdBackScreen) for (auto &k : keys) k.longEvent = false;
  updateBattery();
  prefs.tick();
  requestTimeSync();
  if (screen == SCR_CLOCK) {
    if (anyPressPending()) {
      for (auto &k : keys) { k.pressedEvent = false; k.longEvent = false; }
      screen = SCR_MENU; menuIndex = 0; lastInteraction = millis();
    }
  } else {
    switch (screen) {
      case SCR_MENU: processMenu(); break;
      case SCR_GAMES: processGameMenu(); break;
      case SCR_BLOCK: processBlock(); break;
      case SCR_BREAKER: processBreaker(); break;
      case SCR_ONELINE: processOneLine(); break;
      case SCR_TTT: processTtt(); break;
      case SCR_SNAKE: processSnake(); break;
      case SCR_PONG: processPong(); break;
      case SCR_JUMPER: processJumper(); break;
      case SCR_REACTION: processReaction(); break;
      case SCR_SIMON: processSimon(); break;
      case SCR_DODGE: processDodge(); break;
      case SCR_CALC: processCalc(); break;
      case SCR_STOPWATCH: processStopwatch(); break;
      case SCR_SETTINGS: processSettings(); break;
      case SCR_WIFI_SCAN: case SCR_NETWORK: case SCR_SCORES: case SCR_ABOUT: processSimpleScreen(); break;
      default: break;
    }
  }
  if (screen == SCR_BREAKER) tickBreaker();
  if (screen == SCR_SNAKE) tickSnake();
  if (screen == SCR_PONG) tickPong();
  if (screen == SCR_JUMPER) tickJumper();
  if (screen == SCR_SIMON) tickSimon();
  if (screen == SCR_DODGE) tickDodge();
  if (oledOk && millis() - lastRender > 100) { lastRender = millis(); renderScreen(); }
  delay(2);
}
