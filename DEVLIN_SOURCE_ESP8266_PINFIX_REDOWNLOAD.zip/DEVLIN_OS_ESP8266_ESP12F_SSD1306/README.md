# DEVLIN OS — Wemos D1 mini ESP8266 ESP-12F / SSD1306 (4 MB)

This is a source-code project, **not a compiled BIN**. Build with the included GitHub Actions workflow before flashing. The OLED I²C mapping is set to the standard Wemos D1 mini ESP8266 pins. The supplied illustration uses ESP32 GPIO labels and must not be copied literally onto an ESP8266 board.

## Target hardware
- Wemos D1 mini, ESP8266 ESP-12F, 4 MB flash
- SSD1306 monochrome I²C OLED, 128×64
- Five active-low buttons wired from GPIO to GND
- Battery sense through the external 100 kΩ + 100 kΩ divider shown in the schematic

## Pin map for Wemos D1 mini ESP8266

| Function | Board label | ESP8266 GPIO |
|---|---|---:|
| OLED SDA | D2 | GPIO4 |
| OLED SCL | D1 | GPIO5 |
| Button 1 Confirm / OK | D7 | GPIO13 |
| Button 2 Down | D6 | GPIO12 |
| Button 5 Up | D5 | GPIO14 |
| Button 3 Back / Left in games | D3 | GPIO0 |
| Button 4 Start / Right in games | D4 | GPIO2 |
| Battery sense divider midpoint | A0 | A0 |

The firmware explicitly calls `Wire.begin(PIN_SDA, PIN_SCL)`: connect OLED SDA to D2/GPIO4 and SCL to D1/GPIO5. Do not use ESP32-only GPIO numbers from the illustration on an ESP8266 board.

## Important hardware notes — read before powering

1. **Boot buttons:** D3/GPIO0 and D4/GPIO2 are ESP8266 boot-strap pins. Both must be HIGH during normal boot. The buttons pull them to GND when pressed, so release Back and Start during power-up, reset, and flashing. If the board fails to boot, check these two buttons/wires first.
2. **OLED supply:** The diagram shows OLED VCC connected to 5V. To avoid possible 5V pull-ups on SDA/SCL reaching the ESP8266's 3.3V-only GPIO, power the OLED from **3V3** unless the exact OLED module is known to include proper I²C level shifting. GND remains common.
3. **Battery supply:** The HW-373/TP4056-style charger shown normally provides the cell's battery voltage, not regulated 5V. Feeding its OUT+ directly into the D1 mini 5V pin can become unstable as the cell discharges. For reliable power, use a suitable 5V boost converter to the board's 5V pin, or a stable regulated 3.3V supply to the 3V3 pin. **Never connect a raw Li-ion cell directly to 3V3**; a full cell reaches 4.2V.
4. **Battery measurement:** The 100 kΩ + 100 kΩ divider midpoint goes to A0 and the divider ends go to battery positive and GND. This assumes a D1 mini board with its onboard A0 divider. Do not copy this to a bare ESP-12F module without checking its ADC input range.
5. Release all buttons during flashing.

## Build from an Android phone
1. Create a GitHub repository and upload the **contents** of this project folder (including hidden `.github` folder), not just the ZIP.
2. Open the repository's **Actions** tab and enable Actions if prompted.
3. Run **Build DEVLIN OS ESP8266 ESP-12F**.
4. Wait for a green successful run. Open the run, download artifact `DEVLIN_OS_ESP12F_SSD1306_4MB`, and extract it.
5. The artifact should contain `DEVLIN_OS_ESP12F_SSD1306_4MB.bin` and `FLASH_INSTRUCTIONS.txt`.

## Flashing
- Chip: ESP8266
- Flash size: 4 MB
- Firmware image address: `0x00000`
- Use an Android flasher that supports ESP8266 over USB OTG and your USB-serial adapter.
- Do not use ESP32 bootloader/partition offsets for this ESP8266 image.
- A successful cloud build is not the same as hardware verification; test the OLED and buttons after flashing.

## Included source features
- DEVLIN OS boot and monochrome OLED menu animations
- Main-menu-only 10-second idle transition to WIB clock; game/feature screens do not time out to the clock
- NTP time sync after connecting to a saved Wi-Fi/hotspot with internet
- Wi-Fi scan and local web portal at `192.168.4.1`
- 30 editable SSID presets with one active AP name at a time
- Calculator with digits 0–9, 00, decimal, sign toggle, clear/delete, +, −, ×, ÷, equals
- Stopwatch, settings, high-score screen
- Ten games: block-placement puzzle, Block Breaker, One Line, Tic-Tac-Toe, Snake, Pong, Pixel Jumper, Reaction Tap, Simon Memory, Dodge Drop

## Limitations
- This project has not been built with the real ESP8266 toolchain or tested on the physical board in this environment.
- The ESP8266 has less RAM than an ESP32; web activity and Wi-Fi scans can affect animation smoothness.
- This source provides an AP and Wi-Fi scanning/configuration, not a full NAT internet repeater. It does not perform deauthentication, credential capture, or multi-SSID beacon flooding.
- Accurate time after a power cut requires NTP after boot or a battery-backed RTC such as DS3231.

Default AP name: `LAUNCHER OS DEV1.1`
Default AP/web password: `devlin1234` (change after setup).
