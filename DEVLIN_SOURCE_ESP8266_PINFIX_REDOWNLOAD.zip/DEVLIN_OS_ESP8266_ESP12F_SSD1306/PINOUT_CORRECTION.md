# DEVLIN OS — corrected pin map for Wemos D1 mini ESP8266

- OLED SDA → D2 / GPIO4
- OLED SCL → D1 / GPIO5
- Confirm / OK → D7 / GPIO13
- Down → D6 / GPIO12
- Up → D5 / GPIO14
- Back / Left in games → D3 / GPIO0
- Start / Right in games → D4 / GPIO2
- Battery divider midpoint → A0

Buttons are active-low: one side of each button goes to its listed GPIO; the other side goes to GND. Firmware configures all button pins as `INPUT_PULLUP`.

**Boot warning:** D3/GPIO0 and D4/GPIO2 are boot-strap pins. Do not hold Back or Start while powering on, resetting, or flashing.

**OLED supply warning:** although the diagram routes OLED VCC to 5V, use 3V3 unless the exact module is confirmed to have proper I²C level shifting. ESP8266 GPIO is not 5V tolerant.

**Battery power warning:** the charger module's battery output is not regulated 5V. Do not assume OUT+ directly into the D1 mini 5V pin is reliable at all battery levels. Use a suitable 5V boost converter or a regulated 3.3V supply. Never feed a raw Li-ion cell to 3V3.

The source package is not a compiled BIN. A successful ESP8266 build and hardware test are still required.
