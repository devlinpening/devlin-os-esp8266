# DEVLIN OS ESP8266 pin-map audit — corrected after re-reading the schematic

## Correct signal mapping
- OLED SDA=D2/GPIO4; OLED SCL=D1/GPIO5
- Confirm=D7/GPIO13
- Down=D6/GPIO12
- Up=D5/GPIO14
- Back=D3/GPIO0
- Start=D4/GPIO2
- Battery divider midpoint=A0

The earlier mapping (Confirm=D6, Down=D5, Up=D0, Start=TX) was incorrect. It has been replaced in `src/main.cpp`, README, pinout notes, and flash instructions.

## Firmware changes in this revision
- `PIN_CONFIRM=13`, `PIN_DOWN=12`, `PIN_UP=14`, `PIN_BACK=0`, `PIN_START=2`
- All five buttons use `INPUT_PULLUP` and are active-low to GND.
- Removed the obsolete D0/GPIO16 special-case input mode.
- OLED initialization uses `Wire.begin(D2/GPIO4, D1/GPIO5)` using standard Wemos D1 mini ESP8266 I²C pins.

## Electrical cautions
- D3/GPIO0 and D4/GPIO2 are boot-strap pins. Release Back and Start during boot/reset/flash.
- The diagram routes OLED VCC to 5V; 3V3 is the safer default unless the OLED module's I²C level shifting is confirmed.
- A TP4056/HW-373-style charger provides cell voltage, not regulated 5V. Directly feeding that to the Wemos 5V input may become unstable as the battery discharges. Use a suitable converter/regulator; never feed raw Li-ion voltage to 3V3.
- A0 divider assumes a D1 mini-style board with an onboard ADC divider.

## Verification status
This revision corrects the pin map and documentation. The actual ESP8266 PlatformIO build and physical-device tests have **not** been run in this environment. Do not describe the firmware as hardware-verified until GitHub Actions builds successfully and the board is tested.
