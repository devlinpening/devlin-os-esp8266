# DEVLIN OS V2.1 - Repair and Feature Notes

## Fixed
- Removed duplicate clock-editor and game function definitions that prevented a clean C++ build.
- Unified clock editor screen identifiers and rendering/input dispatch.
- Corrected One Line progression: levels advance from 3x3 to 4x3 to 4x4, and each round marks a target endpoint. The user can undo steps and retry a wrong endpoint.
- Improved Block Blast feedback so users can see when a piece cannot fit and how many rows/columns were cleared.
- Corrected the Simon highlight condition and standardized casual game randomness through the SDK-backed helper.
- Adjusted OLED grid layouts so Minesweeper, One Line, Lights Out and Memory Pairs do not cover the bottom instruction line.

## Games
- 19 games total: Block Blast, Block Breaker, One Line, Tic-Tac-Toe 2P, Snake, Pong, Pixel Jumper, Reaction Tap, Simon Memory, Dodge Drop, Roulette 0-36, Coin Flip, Minesweeper, 2048, RPS vs CPU, Dice Roller, Number Guess, Lights Out, and Memory Pairs.
- Roulette uses outcomes 0 through 36 and European red/black/green classification.
- Coin Flip includes a visual coin, animation, H/T counts, and streak tracking.
- Lights Out creates solvable puzzles by scrambling the solved board with valid moves.
- Memory Pairs uses a shuffled 16-card deck, match tracking, and a short reveal delay for incorrect pairs.

## Clock and Wi-Fi
- Wi-Fi can be toggled from OLED Settings. The web control page also exposes a Wi-Fi toggle.
- Clock time continues while powered even when Wi-Fi is disconnected. The offline editor lets users set date/time without a hotspot.
- Saved epoch checkpointing is every six hours to reduce flash wear. Without a battery-backed RTC, the device cannot measure elapsed time while completely powered off; after a power loss the saved time may be behind by up to about six hours until manually set or synchronized.

## Build status
- The source is repaired and checked statically in this environment. No ESP8266/PlatformIO compiler was available during this run, so this package does not claim that the code has been compiled or hardware-tested. Build with the included GitHub Actions workflow and only flash the generated BIN after a successful build.
