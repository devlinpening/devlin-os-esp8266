# DEVLIN OS V2.1 — Wemos D1 mini ESP8266 ESP-12F / SSD1306 (4 MB)

This is a source-code project, **not a compiled BIN**. Build with the included GitHub Actions workflow before flashing. The OLED I²C mapping is set to the standard Wemos D1 mini ESP8266 pins. The supplied illustration uses ESP32 GPIO labels and must not be copied literally onto an ESP8266 board.

## Target hardware
- Wemos D1 mini, ESP8266 ESP-12F, 4 MB flash
- SSD1306 monochrome I²C OLED, 128×64
- Five active-low buttons wired from GPIO to GND
- Battery sense through the external 100 kΩ + 100 kΩ divider shown in the schematic

## Pin map for Wemos D1 mini ESP8266

| Function | Board label | ESP8266 GPIO |
|---|---|---:|
| OLED SDA | D2 | GPIO4 |
| OLED SCL | D1 | GPIO5 |
| Button 1 Confirm / OK | D7 | GPIO13 |
| Button 2 Down | D6 | GPIO12 |
| Button 5 Up | D5 | GPIO14 |
| Button 3 Back / Left in games | D3 | GPIO0 |
| Button 4 Start / Right in games | D4 | GPIO2 |
| Battery sense divider midpoint | A0 | A0 |

The firmware explicitly calls `Wire.begin(PIN_SDA, PIN_SCL)`: connect OLED SDA to D2/GPIO4 and SCL to D1/GPIO5. Do not use ESP32-only GPIO numbers from the illustration on an ESP8266 board.

## Important hardware notes — read before powering

1. **Boot buttons:** D3/GPIO0 and D4/GPIO2 are ESP8266 boot-strap pins. Both must be HIGH during normal boot. The buttons pull them to GND when pressed, so release Back and Start during power-up, reset, and flashing. If the board fails to boot, check these two buttons/wires first.
2. **OLED supply:** The diagram shows OLED VCC connected to 5V. To avoid possible 5V pull-ups on SDA/SCL reaching the ESP8266's 3.3V-only GPIO, power the OLED from **3V3** unless the exact OLED module is known to include proper I²C level shifting. GND remains common.
3. **Battery supply:** The HW-373/TP4056-style charger shown normally provides the cell's battery voltage, not regulated 5V. Feeding its OUT+ directly into the D1 mini 5V pin can become unstable as the cell discharges. For reliable power, use a suitable 5V boost converter to the board's 5V pin, or a stable regulated 3.3V supply to the 3V3 pin. **Never connect a raw Li-ion cell directly to 3V3**; a full cell reaches 4.2V.
4. **Battery measurement:** The 100 kΩ + 100 kΩ divider midpoint goes to A0 and the divider ends go to battery positive and GND. This assumes a D1 mini board with its onboard A0 divider. Do not copy this to a bare ESP-12F module without checking its ADC input range.
5. Release all buttons during flashing.

## Build from an Android phone
1. Create a GitHub repository and upload the **contents** of this project folder (including hidden `.github` folder), not just the ZIP.
2. Open the repository's **Actions** tab and enable Actions if prompted.
3. Run **Build DEVLIN OS ESP8266 ESP-12F**.
4. Wait for a green successful run. Open the run, download artifact `DEVLIN_OS_ESP12F_SSD1306_4MB`, and extract it.
5. The artifact should contain `DEVLIN_OS_ESP12F_SSD1306_4MB.bin` and `FLASH_INSTRUCTIONS.txt`.

## Flashing
- Chip: ESP8266
- Flash size: 4 MB
- Firmware image address: `0x00000`
- Use an Android flasher that supports ESP8266 over USB OTG and your USB-serial adapter.
- Do not use ESP32 bootloader/partition offsets for this ESP8266 image.
- A successful cloud build is not the same as hardware verification; test the OLED and buttons after flashing.

## Included source features
- DEVLIN OS boot and monochrome OLED menu animations
- Main-menu-only 10-second idle transition to WIB clock; game/feature screens do not time out to the clock
- NTP time sync after connecting to a saved Wi-Fi/hotspot with internet; saved epoch checkpoint lets the clock keep running offline while the board remains powered
- Wi-Fi scan and local web portal at `192.168.4.1`
- 30 editable SSID presets with one active AP name at a time
- Calculator with digits 0–9, 00, decimal, sign toggle, clear/delete, +, −, ×, ÷, equals
- Stopwatch, settings with Wi-Fi radio ON/OFF, animation and auto-clock switches, high-score screen
- Nineteen games: Block Blast with row/column clear feedback, Block Breaker with corrected brick collisions, multi-level One Line with a target endpoint, local 2-player Tic-Tac-Toe, Snake, Pong, Pixel Jumper, Reaction Tap, Simon Memory, Dodge Drop, European roulette 0–36, animated coin flip, 4×4 Minesweeper, 2048, RPS vs CPU, Dice Roller, Number Guess, Lights Out, and Memory Pairs

## Quick controls
- Menus: Up/Down to move, Confirm/OK or Start to open/select, Back to return.
- Most games: hold Back for about 0.8 seconds to exit. A short Back press may act as Left in games that use four-direction movement.
- Block Blast: Up/Down move vertically, Back/Start move left/right, OK places the four-cell piece. `CLR` shows the number of rows/columns cleared; `NO FIT` means move to an empty location.
- One Line: use Up/Down/Back/Start to trace every dot and finish at the double-ring target; OK undoes the last step. Complete a level and press OK/Start to advance.
- Roulette: OK/Start spins a European roulette result from 0 to 36. Coin Flip: OK/Start flips the coin.
- Lights Out: move the cursor and press OK to toggle the selected light and its orthogonal neighbors until all lights are off.
- Memory Pairs: navigate the 4×4 board and press OK to reveal cards; match all eight pairs.
- Settings: select `Wi-Fi radio` to turn the radio ON/OFF. Select `Set clock offline`; Up/Down change the selected value, Back/Start change fields, and OK saves the time.

## Limitations
- This project has not been built with the real ESP8266 toolchain or tested on the physical board in this environment.
- The ESP8266 has less RAM than an ESP32; web activity and Wi-Fi scans can affect animation smoothness.
- This source provides an AP and Wi-Fi scanning/configuration, not a full NAT internet repeater. It does not perform deauthentication, credential capture, or multi-SSID beacon flooding.
- Without a battery-backed RTC, time elapsed while fully powered off cannot be measured. The saved checkpoint may be behind by up to six hours; synchronize or correct the clock after a long power loss.

Default AP name: `DEVLIN-OS-V2.1`
Default AP/web password: `devlin1234` (change after setup).


## V2.1 changes
- Added European roulette with a 0–36 result and standard red/black/green number classification.
- Added animated coin flip (heads/tails).
- Added 4×4 Minesweeper and a playable 2048 tile-merging puzzle.
- Upgraded One Line to progressive 3×3, 4×3 and 4×4 stages with randomized start positions, a marked target endpoint, undo and retry behavior.
- Fixed Block Breaker collision detection by testing actual brick rectangles and correcting the old vertical offset.
- Block Blast now chooses a randomized piece after every placement and continues to clear complete rows and columns.
- Added a Wi-Fi radio ON/OFF switch in Settings. The clock can continue from its saved time checkpoint without a connection while the device stays powered. Saved clock checkpoints are written every six hours to reduce flash wear. After a power loss, the saved time may be behind by up to about six hours; exact time during a full power-off requires a battery-backed RTC or a later sync/manual correction.
- Existing Tic-Tac-Toe remains the local two-player game; roulette and coin flip are single-player/random-result tools.

## Build status
The source package has been updated, but this environment does not have the ESP8266/PlatformIO toolchain available and network access prevented installing it. Therefore **no V2.1 binary is included or claimed to be compiled**. Upload this source project to GitHub and run the included Actions workflow; only flash the BIN produced by a successful green build. Hardware playtesting is still required.
